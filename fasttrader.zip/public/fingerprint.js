/* ============================================================
   BROWSER FINGERPRINT — Deteksi unik per browser
   Menggabungkan banyak data untuk menghasilkan hash unik
   ============================================================ */
(function (global) {
  'use strict';

  const FP_KEY = 'bfp_id_v1';

  // ============================================================
  // Fungsi hash (djb2 + mixing) → 16 hex char
  // ============================================================
  function hashString(str) {
    let h1 = 0xdeadbeef, h2 = 0x41c6ce57;
    for (let i = 0; i < str.length; i++) {
      const ch = str.charCodeAt(i);
      h1 = Math.imul(h1 ^ ch, 2654435761);
      h2 = Math.imul(h2 ^ ch, 1597334677);
    }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507);
    h1 ^= Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507);
    h2 ^= Math.imul(h1 ^ (h1 >>> 13), 3266489909);
    const h = 4294967296 * (2097151 & h2) + (h1 >>> 0);
    return h.toString(16).padStart(16, '0');
  }

  // ============================================================
  // Canvas fingerprint
  // ============================================================
  function getCanvasFingerprint() {
    try {
      const canvas = document.createElement('canvas');
      canvas.width = 220;
      canvas.height = 40;
      const ctx = canvas.getContext('2d');
      if (!ctx) return 'no-canvas';

      ctx.fillStyle = '#f0f0f0';
      ctx.fillRect(0, 0, 220, 40);

      ctx.textBaseline = 'top';
      ctx.font = '14px "Arial"';
      ctx.fillStyle = '#22c55e';
      ctx.fillText('FastTrader-BFP-2024', 2, 2);

      ctx.font = '12px "Times New Roman"';
      ctx.fillStyle = 'rgba(102, 204, 0, 0.7)';
      ctx.fillText('Canvas fingerprint test 🎯', 4, 20);

      const gradient = ctx.createLinearGradient(0, 0, 220, 0);
      gradient.addColorStop(0, 'rgba(255,0,0,0.3)');
      gradient.addColorStop(0.5, 'rgba(0,255,0,0.3)');
      gradient.addColorStop(1, 'rgba(0,0,255,0.3)');
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 30, 220, 10);

      const data = canvas.toDataURL();
      return data.slice(-100);
    } catch (e) {
      return 'canvas-error';
    }
  }

  // ============================================================
  // WebGL fingerprint
  // ============================================================
  function getWebGLFingerprint() {
    try {
      const canvas = document.createElement('canvas');
      const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
      if (!gl) return 'no-webgl';

      const debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
      const vendor = debugInfo ? gl.getParameter(debugInfo.UNMASKED_VENDOR_WEBGL) : 'unknown';
      const renderer = debugInfo ? gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL) : 'unknown';

      return vendor + '|' + renderer;
    } catch (e) {
      return 'webgl-error';
    }
  }

  // ============================================================
  // Audio fingerprint (ringan)
  // ============================================================
  function getAudioFingerprint() {
    try {
      const AudioContext = window.OfflineAudioContext || window.webkitOfflineAudioContext;
      if (!AudioContext) return 'no-audio';

      const ctx = new AudioContext(1, 44100, 44100);
      const osc = ctx.createOscillator();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(10000, ctx.currentTime);

      const compressor = ctx.createDynamicsCompressor();
      compressor.threshold.setValueAtTime(-50, ctx.currentTime);
      compressor.knee.setValueAtTime(40, ctx.currentTime);
      compressor.ratio.setValueAtTime(12, ctx.currentTime);
      compressor.attack.setValueAtTime(0, ctx.currentTime);
      compressor.release.setValueAtTime(0.25, ctx.currentTime);

      osc.connect(compressor);
      compressor.connect(ctx.destination);
      osc.start(0);

      return 'audio-' + hashString(
        osc.type + '|' +
        compressor.threshold.value + '|' +
        compressor.ratio.value
      );
    } catch (e) {
      return 'audio-error';
    }
  }

  // ============================================================
  // Kumpulkan semua data
  // ============================================================
  function collectFingerprintData() {
    const nav = navigator || {};
    const scr = screen || {};

    return {
      ua: nav.userAgent || '',
      lang: nav.language || '',
      langs: (nav.languages || []).join(','),
      platform: nav.platform || '',
      vendor: nav.vendor || '',
      product: nav.product || '',
      productSub: nav.productSub || '',
      cores: nav.hardwareConcurrency || 0,
      memory: nav.deviceMemory || 0,
      touchPoints: nav.maxTouchPoints || 0,
      screenW: scr.width || 0,
      screenH: scr.height || 0,
      availW: scr.availWidth || 0,
      availH: scr.availHeight || 0,
      colorDepth: scr.colorDepth || 0,
      pixelRatio: window.devicePixelRatio || 1,
      timezone: (function() {
        try { return Intl.DateTimeFormat().resolvedOptions().timeZone || ''; }
        catch (e) { return ''; }
      })(),
      tzOffset: new Date().getTimezoneOffset(),
      canvas: getCanvasFingerprint(),
      webgl: getWebGLFingerprint(),
      audio: getAudioFingerprint(),
      cookieEnabled: !!nav.cookieEnabled,
      doNotTrack: nav.doNotTrack || '',
      pdfViewer: !!nav.pdfViewerEnabled,
      winW: window.innerWidth || 0,
      winH: window.innerHeight || 0
    };
  }

  // ============================================================
  // Generate fingerprint ID
  // ============================================================
  function generateFingerprint() {
    const data = collectFingerprintData();
    const keys = Object.keys(data).sort();
    const str = keys.map(k => k + '=' + data[k]).join('|');
    return hashString(str);
  }

  // ============================================================
  // Get fingerprint (cached)
  // ============================================================
  function getFingerprint() {
    try {
      const cached = localStorage.getItem(FP_KEY);
      if (cached && cached.length >= 16) return cached;
    } catch (e) {}

    const fp = generateFingerprint();

    try { localStorage.setItem(FP_KEY, fp); } catch (e) {}

    return fp;
  }

  function resetFingerprint() {
    try { localStorage.removeItem(FP_KEY); } catch (e) {}
    return getFingerprint();
  }

  // ============================================================
  // Export global
  // ============================================================
  global.BrowserFP = {
    get: getFingerprint,
    reset: resetFingerprint,
    generate: generateFingerprint
  };

})(window);