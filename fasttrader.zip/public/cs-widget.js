/* ============================================================
   CS WIDGET — Floating Customer Service
   Draggable FAB + Auto Reply + Detail + Context-Aware
   ============================================================ */
(function () {
  'use strict';

  // ============================================================
  // CONFIG
  // ============================================================
  const CS_NAME = 'CS Fast Trader';
  const CS_STATUS = 'Online — balas otomatis';
  const STORAGE_KEY = 'cs_chat_history_v1';
  const OPEN_KEY = 'cs_panel_open';
  const CONTEXT_KEY = 'cs_context_v1';
  const POS_KEY = 'cs_fab_position_v1';
  const CS_TELEGRAM = '@admin_fasttrader';

  const DRAG = {
    SNAP_TO_EDGE: true,
    SNAP_MARGIN: 16,
    DRAG_THRESHOLD: 5,
    EDGE_PADDING: 8
  };

  // ============================================================
  // AUTO-REPLY RULES
  // ============================================================
  let AUTO_REPLIES = [

    // ---------- SALDO / TOPUP BELUM MASUK ----------
    {
      id: 'saldo_gak_masuk',
      topic: 'saldo_masalah',
      match: [
        'saldo gak masuk', 'saldo ga masuk', 'saldo tidak masuk', 'saldo belum masuk',
        'saldo gk masuk', 'saldo blm masuk', 'saldo blom masuk',
        'topup gak masuk', 'topup ga masuk', 'topup tidak masuk', 'topup belum masuk',
        'deposit gak masuk', 'deposit ga masuk', 'deposit belum masuk',
        'udah bayar belum masuk', 'sudah bayar belum masuk',
        'udah transfer belum masuk', 'sudah transfer belum masuk',
        'kok belum masuk', 'kok gak masuk', 'kok ga masuk',
        'saldo hilang', 'saldo ngurang', 'saldo berkurang sendiri'
      ],
      patterns: [
        /\b(saldo|topup|top\s*up|deposit|isi\s*saldo)\b.{0,30}\b(gak|ga|gk|tdk|tidak|belum|blm|blom|engga|enggak|kagak|gmasuk|ga\s*masuk|gak\s*masuk|tidak\s*masuk|belum\s*masuk)\b/i,
        /\b(kok|kenapa|knp|ngapa|napa|mengapa)\b.{0,30}\b(saldo|topup|deposit)\b.{0,30}\b(gak|ga|gk|tidak|belum|blm|kagak)\b/i,
        /\b(udah|udh|sudah|sdh)\b.{0,20}\b(bayar|transfer|topup|deposit)\b.{0,30}\b(belum|blm|gak|ga|gk|tidak)\b.{0,20}\b(masuk|msk|bertambah|nambah|keisi)\b/i,
        /\b(bayar|transfer|topup|deposit)\b.{0,30}\b(tapi|tp|tpi)\b.{0,30}\b(belum|blm|gak|ga|gk|tidak)\b.{0,20}\b(masuk|msk|nambah|bertambah)\b/i
      ],
      reply: () =>
        'Baik, saya paham. Saldo/topup Anda belum masuk ya? 🙏\n\n' +
        '━━━━━━━━━━━━━━━━━━━━\n' +
        '⚡ *CEK CEPAT:*\n' +
        '━━━━━━━━━━━━━━━━━━━━\n\n' +
        '*1. Tunggu 1-5 menit dulu*\n' +
        '   Sistem kami cek pembayaran QRIS otomatis. Biasanya masuk dalam 1-5 menit setelah bayar.\n\n' +
        '*2. Cek menu "Riwayat Transaksi"*\n' +
        '   Login → Dashboard → Riwayat Transaksi\n' +
        '   Cari transaksi terakhir Anda.\n\n' +
        '*3. Perhatikan status transaksi:*\n' +
        '   • ✅ *SUCCESS* → saldo sudah masuk\n' +
        '   • ⏳ *PENDING* → tunggu, sistem masih proses\n' +
        '   • ❌ *EXPIRED* → QRIS kadaluarsa (30 menit), buat ulang\n' +
        '   • ❌ *FAILED* → pembayaran gagal, coba lagi\n\n' +
        '━━━━━━━━━━━━━━━━━━━━\n' +
        '📞 *KALAU MASIH BELUM MASUK:*\n' +
        '━━━━━━━━━━━━━━━━━━━━\n\n' +
        'Siapkan 3 hal ini:\n' +
        '1. Screenshot bukti bayar (struk QRIS / mutasi bank)\n' +
        '2. ID transaksi (lihat di Riwayat Transaksi)\n' +
        '3. Username akun Anda\n\n' +
        'Kirim ke Telegram admin: ' + CS_TELEGRAM + '\n\n' +
        'Admin akan cek & proses manual dalam *1x24 jam* ⏱️',
      followUp: 'Apakah status transaksi Anda *PENDING*, *SUCCESS*, atau *EXPIRED*?',
      options: ['Status PENDING', 'Status SUCCESS', 'Status EXPIRED', 'Status FAILED']
    },

    // ---------- WITHDRAW BELUM MASUK ----------
    {
      id: 'wd_belum_masuk',
      topic: 'wd_masalah',
      match: [
        'wd gak masuk', 'wd ga masuk', 'wd belum masuk', 'wd belum cair',
        'withdraw gak masuk', 'withdraw belum masuk', 'withdraw belum cair',
        'penarikan belum masuk', 'penarikan belum cair',
        'wd lama', 'withdraw lama', 'penarikan lama',
        'belum di proses', 'belum diproses', 'masih pending',
        'wd pending', 'withdraw pending'
      ],
      patterns: [
        /\b(wd|withdraw|penarikan|tarik\s*saldo|tarik\s*duit|pencairan|cairin|cairkan)\b.{0,30}\b(belum|blm|gak|ga|gk|tidak|blom|engga|enggak|lama|lambat|pending|nunggu|diproses)\b/i,
        /\b(kapan|kpn|kok|kenapa|knp|ngapa|napa)\b.{0,30}\b(wd|withdraw|penarikan|cair|pencairan)\b/i,
        /\b(masih|msh)\b.{0,20}\b(pending|nunggu|diproses|proses)\b/i
      ],
      reply: () =>
        'Oke, saya bantu cek. Withdraw Anda belum masuk ya? ⏳\n\n' +
        '━━━━━━━━━━━━━━━━━━━━\n' +
        '📋 *STATUS WITHDRAW:*\n' +
        '━━━━━━━━━━━━━━━━━━━━\n\n' +
        'Proses normal: *1x24 jam kerja*\n' +
        '(Senin-Jumat, jam 09.00-22.00 WIB)\n\n' +
        'Cek status di: Dashboard → Riwayat Withdraw\n\n' +
        '*Arti status:*\n' +
        '• ⏳ *PENDING* → masih menunggu review admin\n' +
        '• ✅ *SUCCESS* → sudah ditransfer ke DANA/GoPay/OVO Anda\n' +
        '• ❌ *REJECTED* → saldo otomatis dikembalikan\n\n' +
        '━━━━━━━━━━━━━━━━━━━━\n' +
        '⏰ *KALAU SUDAH LEBIH 24 JAM:*\n' +
        '━━━━━━━━━━━━━━━━━━━━\n\n' +
        'Kirim ke admin ' + CS_TELEGRAM + ':\n' +
        '1. ID Withdraw (format: WD-xxxx)\n' +
        '2. Username akun\n' +
        '3. Nominal WD\n' +
        '4. Metode (DANA/GoPay/OVO)',
      followUp: 'Status withdraw Anda sekarang *PENDING* atau sudah *SUCCESS*?',
      options: ['Masih PENDING', 'Sudah SUCCESS', 'Status REJECTED']
    },

    // ---------- LOGIN GAGAL ----------
    {
      id: 'login_fail',
      topic: 'login_masalah',
      match: [
        'gabisa login', 'gak bisa login', 'tidak bisa login', 'gagal login',
        'error login', 'login gagal', 'susah login', 'login gak bisa',
        'gak bisa masuk', 'tidak bisa masuk', 'gabisa masuk',
        'akun kena blokir', 'akun diblokir', 'akun terkunci'
      ],
      patterns: [
        /\b(gak|ga|gk|tidak|tdk|gabisa|engga|enggak|kagak|kaga)\b.{0,20}\b(login|masuk|sign\s*in)\b/i,
        /\b(login|masuk)\b.{0,20}\b(gak|ga|gk|tidak|tdk|gagal|error|susah|sulit|kendala|masalah|eror)\b/i
      ],
      reply: () =>
        'Aduh, mohon maaf ya kalau login-nya bermasalah 🙏\n\n' +
        '━━━━━━━━━━━━━━━━━━━━\n' +
        '🔐 *CEK LANGKAH INI:*\n' +
        '━━━━━━━━━━━━━━━━━━━━\n\n' +
        '*1. Pastikan username & password benar*\n' +
        '   • Username: huruf kecil semua\n' +
        '   • Password: perhatikan besar-kecil huruf\n\n' +
        '*2. Cek Caps Lock*\n' +
        '   Kadang Caps Lock nyala tanpa sadar.\n\n' +
        '*3. Coba browser lain*\n' +
        '   Chrome, Firefox, Safari, atau mode Incognito.\n\n' +
        '*4. Bersihkan cache & cookies*\n' +
        '   Setting browser → Clear Data.\n\n' +
        '*5. Reset password*\n' +
        '   Klik "Lupa Password" di halaman login.\n\n' +
        '━━━━━━━━━━━━━━━━━━━━\n' +
        '📞 *MASIH GAGAL?*\n' +
        '━━━━━━━━━━━━━━━━━━━━\n\n' +
        'Kirim ke ' + CS_TELEGRAM + ':\n' +
        '• Username akun\n' +
        '• Screenshot error\n' +
        '• Waktu kejadian',
      followUp: 'Pesan error yang muncul apa?',
      options: ['Password salah', 'Akun tidak ditemukan', 'Halaman blank/error', 'Tidak ada notif']
    },

    // ---------- LUPA PASSWORD ----------
    {
      id: 'lupa_password',
      topic: 'password_masalah',
      match: [
        'lupa password', 'reset password', 'ganti password', 'ubah password',
        'password lupa', 'password salah', 'password gak bisa',
        'password salah terus', 'pass salah', 'pw salah'
      ],
      patterns: [
        /\b(lupa|ilang|hilang|salah|ganti|ubah|reset)\b.{0,20}\b(password|pass|pw|sandi)\b/i,
        /\b(password|pass|pw|sandi)\b.{0,20}\b(lupa|salah|ganti|ubah|reset|hilang|ilang)\b/i
      ],
      reply: () =>
        'Siap, saya bantu untuk masalah password 🙏\n\n' +
        '━━━━━━━━━━━━━━━━━━━━\n' +
        '🔑 *RESET PASSWORD:*\n' +
        '━━━━━━━━━━━━━━━━━━━━\n\n' +
        '*1.* Logout dari akun (kalau masih login)\n\n' +
        '*2.* Buka halaman Login\n\n' +
        '*3.* Klik link *"Lupa Password"*\n\n' +
        '*4.* Masukkan email yang terdaftar\n\n' +
        '*5.* Cek inbox email → klik link reset\n' +
        '   _(cek juga folder Spam/Promotions)_\n\n' +
        '*6.* Buat password baru\n' +
        '   • Minimal 6 karakter\n' +
        '   • Kombinasi huruf & angka lebih aman\n\n' +
        '━━━━━━━━━━━━━━━━━━━━\n' +
        '📞 *EMAIL TIDAK MASUK?*\n' +
        '━━━━━━━━━━━━━━━━━━━━\n\n' +
        'Hubungi ' + CS_TELEGRAM + ' dengan:\n' +
        '• Username akun\n' +
        '• Email yang terdaftar',
      followUp: 'Anda masih ingat *email* yang dipakai untuk daftar?',
      options: ['Ya, masih ingat', 'Lupa email', 'Email sudah tidak aktif']
    },

    // ---------- ERROR / BUG ----------
    {
      id: 'error_umum',
      topic: 'error_umum',
      match: [
        'lapor error', 'lapor bug', 'ada error', 'ada bug', 'ada eror',
        'website rusak', 'web rusak', 'aplikasi rusak', 'app rusak',
        'tidak bisa akses', 'gabisa akses', 'gak bisa akses',
        'web error', 'website error', 'server error',
        'halaman putih', 'blank putih', 'loading terus'
      ],
      patterns: [
        /\b(web|website|aplikasi|app|halaman|page|server|sistem|situs|situsnya|webnya|aplikasinya)\b.{0,20}\b(error|eror|rusak|blank|putih|loading|lemot|lag|hang|gabisa|gak\s*bisa|tidak\s*bisa)\b/i,
        /\b(error|eror|rusak|blank|putih|loading|lemot|lag|hang)\b.{0,20}\b(web|website|aplikasi|app|halaman|server|sistem)\b/i
      ],
      reply: () =>
        'Mohon maaf atas kendalanya 🙏\n\n' +
        '━━━━━━━━━━━━━━━━━━━━\n' +
        '🔧 *COBA LANGKAH INI:*\n' +
        '━━━━━━━━━━━━━━━━━━━━\n\n' +
        '*1. Refresh halaman*\n' +
        '   Tekan Ctrl+F5 (Windows) / Cmd+R (Mac)\n\n' +
        '*2. Bersihkan cache browser*\n' +
        '   Setting → Clear browsing data\n\n' +
        '*3. Coba browser lain*\n' +
        '   Chrome / Firefox / Safari / Edge\n\n' +
        '*4. Cek koneksi internet*\n' +
        '   Pastikan stabil, coba matikan-nyalakan WiFi\n\n' +
        '*5. Coba mode Incognito*\n' +
        '   Ctrl+Shift+N (Windows) / Cmd+Shift+N (Mac)\n\n' +
        '*6. Logout lalu login ulang*\n\n' +
        '━━━━━━━━━━━━━━━━━━━━\n' +
        '📞 *MASIH ERROR?*\n' +
        '━━━━━━━━━━━━━━━━━━━━\n\n' +
        'Kirim ke ' + CS_TELEGRAM + ':\n' +
        '1. 📸 Screenshot error\n' +
        '2. Halaman mana yang error?\n' +
        '3. Waktu kejadian (jam berapa)\n' +
        '4. Browser + HP yang dipakai',
      followUp: 'Error muncul di halaman apa?',
      options: ['Dashboard', 'Halaman Topup', 'Halaman Withdraw', 'Halaman Investasi', 'Halaman Login']
    },

    // ---------- BONUS BELUM MASUK ----------
    {
      id: 'bonus_gak_masuk',
      topic: 'bonus_masalah',
      match: [
        'bonus gak masuk', 'bonus ga masuk', 'bonus belum masuk',
        'bonus tidak masuk', 'bonus gk masuk',
        'komisi gak masuk', 'komisi belum masuk',
        'referral gak masuk', 'referral belum masuk', 'reff gak masuk'
      ],
      patterns: [
        /\b(bonus|komisi|referral|reff|hadiah|reward)\b.{0,30}\b(gak|ga|gk|tidak|belum|blm|blom|engga|enggak|kagak)\b.{0,20}\b(masuk|msk|nambah|bertambah|dapat|dapet|terima)\b/i,
        /\b(gak|ga|gk|tidak|belum|blm)\b.{0,20}\b(dapat|dapet|terima|masuk|nambah|bertambah)\b.{0,30}\b(bonus|komisi|referral|reff|hadiah|reward)\b/i
      ],
      reply: () =>
        'Baik, saya bantu cek bonus Anda 🙏\n\n' +
        '━━━━━━━━━━━━━━━━━━━━\n' +
        '🎁 *SYARAT BONUS REFERRAL:*\n' +
        '━━━━━━━━━━━━━━━━━━━━\n\n' +
        'Bonus masuk *otomatis* ketika:\n' +
        '✅ Teman daftar pakai kode referral Anda\n' +
        '✅ Teman sudah punya akun aktif\n\n' +
        '━━━━━━━━━━━━━━━━━━━━\n' +
        '📋 *CEK DULU:*\n' +
        '━━━━━━━━━━━━━━━━━━━━\n\n' +
        '*1.* Buka Dashboard → Menu "Referral"\n\n' +
        '*2.* Lihat daftar "Downline" Anda\n\n' +
        '*3.* Cek jumlah referral_count\n\n' +
        '*4.* Bandingkan dengan saldo bonus\n\n' +
        '━━━━━━━━━━━━━━━━━━━━\n' +
        '📞 *KALAU SUDAH SESUAI TAPI BELUM MASUK:*\n' +
        '━━━━━━━━━━━━━━━━━━━━\n\n' +
        'Kirim ke ' + CS_TELEGRAM + ':\n' +
        '1. Username Anda\n' +
        '2. Username teman yang direfer\n' +
        '3. Screenshot daftar downline',
      followUp: 'Teman Anda yang direfer sudah *daftar berhasil* belum?',
      options: ['Sudah daftar', 'Belum daftar', 'Tidak yakin']
    },

    // ---------- PROFIT HARIAN BELUM MASUK ----------
    {
      id: 'profit_gak_masuk',
      topic: 'profit_masalah',
      match: [
        'profit gak masuk', 'profit ga masuk', 'profit belum masuk',
        'profit tidak masuk', 'profit gk masuk',
        'keuntungan gak masuk', 'keuntungan belum masuk',
        'harian gak masuk', 'harian belum masuk',
        'pendapatan gak masuk', 'pendapatan belum masuk'
      ],
      patterns: [
        /\b(profit|keuntungan|harian|pendapatan|income|bunga|cuan|hasil)\b.{0,30}\b(gak|ga|gk|tidak|belum|blm|blom|engga|enggak|kagak)\b.{0,20}\b(masuk|msk|nambah|bertambah|dapat|dapet|terima)\b/i,
        /\b(gak|ga|gk|tidak|belum|blm)\b.{0,20}\b(dapat|dapet|terima|masuk|nambah|bertambah)\b.{0,30}\b(profit|keuntungan|harian|pendapatan|income)\b/i
      ],
      reply: () =>
        'Oke, saya bantu cek profit harian Anda 📈\n\n' +
        '━━━━━━━━━━━━━━━━━━━━\n' +
        '⏰ *JADWAL PROFIT:*\n' +
        '━━━━━━━━━━━━━━━━━━━━\n\n' +
        'Profit masuk *otomatis setiap hari*\n' +
        'Jam *00.00 WIB* (tengah malam)\n\n' +
        'Cek di: Dashboard → Investasi Saya\n\n' +
        '━━━━━━━━━━━━━━━━━━━━\n' +
        '📋 *CEK STATUS INVESTASI:*\n' +
        '━━━━━━━━━━━━━━━━━━━━\n\n' +
        '• ✅ *Aktif* → profit akan terus masuk tiap hari\n' +
        '• 🏁 *Selesai* → sudah lewat 30 hari, profit stop\n' +
        '• ❌ *Gagal* → hubungi admin\n\n' +
        'Perhatikan kolom:\n' +
        '• *Hari ke-* : sudah lewat berapa hari\n' +
        '• *Total Earned* : total profit yang sudah diterima\n\n' +
        '━━━━━━━━━━━━━━━━━━━━\n' +
        '📞 *KALAU SUDAH LEWAT 00.00 TAPI BELUM MASUK:*\n' +
        '━━━━━━━━━━━━━━━━━━━━\n\n' +
        'Kirim ke ' + CS_TELEGRAM + ':\n' +
        '1. Username\n' +
        '2. ID Investasi\n' +
        '3. Screenshot menu "Investasi Saya"',
      followUp: 'Investasi Anda statusnya sekarang *Aktif* atau *Selesai*?',
      options: ['Masih Aktif', 'Sudah Selesai', 'Tidak ada investasi']
    },

    // ---------- MASALAH HP ----------
    {
      id: 'masalah_hp',
      topic: 'masalah_hp',
      match: [
        'hp gak bisa', 'hp tidak bisa', 'aplikasi gak jalan', 'aplikasi error',
        'layar putih', 'layar blank', 'gak bisa dibuka', 'tidak bisa dibuka',
        'web lemot', 'web loading terus', 'loading trs'
      ],
      patterns: [
        /\b(hp|handphone|ponsel|android|iphone|ios)\b.{0,20}\b(gak|ga|gk|tidak|error|rusak|lemot|blank|hang)\b/i,
        /\b(lemot|lag|hang|blank|putih|loading)\b.{0,20}\b(hp|aplikasi|web|browser|halaman)\b/i
      ],
      reply: () =>
        'Mohon maaf atas kendala di HP Anda 🙏\n\n' +
        '━━━━━━━━━━━━━━━━━━━━\n' +
        '📱 *LANGKAH PERBAIKAN:*\n' +
        '━━━━━━━━━━━━━━━━━━━━\n\n' +
        '*1. Refresh halaman*\n' +
        '   Tarik ke bawah (pull to refresh)\n\n' +
        '*2. Bersihkan cache browser*\n' +
        '   Chrome: ⋮ → History → Clear browsing data\n' +
        '   Safari: Settings → Safari → Clear History\n\n' +
        '*3. Coba browser lain*\n' +
        '   Chrome, Firefox, Opera Mini, Edge\n\n' +
        '*4. Cek koneksi internet*\n' +
        '   • Coba WiFi ↔ Data seluler\n' +
        '   • Restart router / HP\n\n' +
        '*5. Update browser*\n' +
        '   Play Store / App Store → Update\n\n' +
        '*6. Restart HP*\n' +
        '   Kadang HP perlu di-restart agar lancar\n\n' +
        '━━━━━━━━━━━━━━━━━━━━\n' +
        '📞 *MASIH BERMASALAH?*\n' +
        '━━━━━━━━━━━━━━━━━━━━\n\n' +
        'Kirim ke ' + CS_TELEGRAM + ':\n' +
        '• 📸 Screenshot\n' +
        '• Merek & tipe HP\n' +
        '• Browser yang dipakai\n' +
        '• Kapan masalah muncul',
      followUp: 'Anda pakai HP *Android* atau *iPhone*?',
      options: ['Android', 'iPhone/iOS', 'Laptop/PC']
    },

    // ---------- CARA TOPUP ----------
    {
      id: 'cara_topup',
      topic: 'cara_topup',
      match: [
        'cara topup', 'cara top up', 'cara isi saldo', 'cara deposit',
        'mau topup', 'ingin topup', 'mau isi saldo',
        'gimana topup', 'gimana caranya topup', 'bagaimana topup'
      ],
      patterns: [
        /\b(cara|gimana|gmn|bagaimana|bgmn|gmana|caranya|tutorial|tutor)\b.{0,20}\b(topup|top\s*up|deposit|isi\s*saldo|isi\s*ulang)\b/i,
        /\b(mau|pengen|pingin|ingin|minat)\b.{0,20}\b(topup|top\s*up|deposit|isi\s*saldo)\b/i
      ],
      reply: () =>
        'Siap, saya jelaskan cara topup 💳\n\n' +
        '━━━━━━━━━━━━━━━━━━━━\n' +
        '📋 *LANGKAH TOPUP:*\n' +
        '━━━━━━━━━━━━━━━━━━━━\n\n' +
        '*1.* Login ke dashboard\n\n' +
        '*2.* Klik menu *"Top Up"*\n\n' +
        '*3.* Pilih nominal:\n' +
        '   • Rp 50.000\n' +
        '   • Rp 60.000\n' +
        '   • Rp 75.000\n' +
        '   • Rp 100.000\n' +
        '   • Rp 200.000\n' +
        '   • Rp 500.000\n' +
        '   _(atau isi manual min Rp 1.000)_\n\n' +
        '*4.* Klik tombol *"Buat QRIS"*\n\n' +
        '*5.* Scan QR pakai aplikasi:\n' +
        '   • DANA\n' +
        '   • GoPay\n' +
        '   • OVO\n' +
        '   • ShopeePay\n' +
        '   • Mobile banking\n\n' +
        '*6.* Konfirmasi bayar\n\n' +
        '*7.* Saldo masuk *otomatis* (1-5 menit)\n\n' +
        '━━━━━━━━━━━━━━━━━━━━\n' +
        '⚠️ *CATATAN PENTING:*\n' +
        '━━━━━━━━━━━━━━━━━━━━\n\n' +
        '• QRIS berlaku *30 menit*\n' +
        '• Kalau lewat 30 menit → status EXPIRED, buat ulang\n' +
        '• Topup TIDAK bisa langsung di-WD, harus beli paket investasi dulu',
      followUp: 'Anda mau topup berapa? Saya bisa bantu jelaskan paketnya.',
      options: ['Rp 50.000', 'Rp 100.000', 'Rp 200.000', 'Rp 500.000']
    },

    // ---------- CARA WITHDRAW ----------
    {
      id: 'cara_withdraw',
      topic: 'cara_withdraw',
      match: [
        'cara withdraw', 'cara wd', 'cara tarik', 'cara penarikan',
        'cara cairkan', 'mau withdraw', 'mau wd', 'ingin withdraw',
        'gimana withdraw', 'gimana wd', 'gimana caranya wd'
      ],
      patterns: [
        /\b(cara|gimana|gmn|bagaimana|bgmn|gmana|caranya|tutorial|tutor)\b.{0,20}\b(withdraw|wd|tarik|penarikan|cairkan|cairin|pencairan)\b/i,
        /\b(mau|pengen|pingin|ingin|minat)\b.{0,20}\b(withdraw|wd|tarik|cairkan|cairin)\b/i
      ],
      reply: () =>
        'Siap, saya jelaskan cara withdraw 💸\n\n' +
        '━━━━━━━━━━━━━━━━━━━━\n' +
        '📋 *LANGKAH WITHDRAW:*\n' +
        '━━━━━━━━━━━━━━━━━━━━\n\n' +
        '*1.* Login ke dashboard\n\n' +
        '*2.* Klik menu *"Withdraw"*\n\n' +
        '*3.* Masukkan nominal (min *Rp 30.000*)\n\n' +
        '*4.* Pilih metode:\n' +
        '   • DANA\n' +
        '   • GoPay\n' +
        '   • OVO\n\n' +
        '*5.* Masukkan nomor akun e-wallet\n\n' +
        '*6.* Masukkan nama pemilik akun\n' +
        '   _(harus sama dengan nama di e-wallet)_\n\n' +
        '*7.* Klik *"Ajukan Withdraw"*\n\n' +
        '*8.* Tunggu proses *1x24 jam kerja*\n\n' +
        '━━━━━━━━━━━━━━━━━━━━\n' +
        '⚠️ *CATATAN PENTING:*\n' +
        '━━━━━━━━━━━━━━━━━━━━\n\n' +
        '• Min: *Rp 30.000*\n' +
        '• Max: *Rp 10.000.000*\n' +
        '• Nama akun WAJIB sesuai\n' +
        '• Saldo top up HARUS dipakai beli paket investasi dulu\n' +
        '• Saldo investasi + profit → bisa langsung WD',
      followUp: 'Anda mau withdraw ke DANA, GoPay, atau OVO?',
      options: ['DANA', 'GoPay', 'OVO']
    },

    // ---------- PAKET INVESTASI ----------
    {
      id: 'paket_invest',
      topic: 'paket_invest',
      match: [
        'paket investasi', 'paket invest', 'cara invest', 'cara investasi',
        'beli paket', 'mau invest', 'mau investasi', 'beli invest',
        'gimana invest', 'gimana investasi', 'info paket'
      ],
      patterns: [
        /\b(cara|gimana|gmn|bagaimana|bgmn|gmana|caranya|tutorial|tutor|info|detail|jelasin|jelaskan)\b.{0,20}\b(invest|investasi|paket|beli\s*paket)\b/i,
        /\b(mau|pengen|pingin|ingin|minat|tertarik)\b.{0,20}\b(invest|investasi|beli\s*paket)\b/i
      ],
      reply: () =>
        'Siap, ini daftar paket investasi kami 📈\n\n' +
        '━━━━━━━━━━━━━━━━━━━━\n' +
        '💼 *PAKET INVESTASI:*\n' +
        '━━━━━━━━━━━━━━━━━━━━\n\n' +
        '🥉 *Starter* — Rp 65.000\n' +
        '   → Kembali: Rp 130.000 (×2.0)\n' +
        '   → Profit/hari: ± Rp 4.333\n\n' +
        '🥉 *Basic* — Rp 75.000\n' +
        '   → Kembali: Rp 150.000 (×2.0)\n' +
        '   → Profit/hari: ± Rp 5.000\n\n' +
        '🥈 *Bronze* — Rp 90.000\n' +
        '   → Kembali: Rp 270.000 (×3.0)\n' +
        '   → Profit/hari: ± Rp 9.000\n\n' +
        '🥈 *Silver* — Rp 120.000\n' +
        '   → Kembali: Rp 360.000 (×3.0)\n' +
        '   → Profit/hari: ± Rp 12.000\n\n' +
        '🥇 *Gold* — Rp 170.000\n' +
        '   → Kembali: Rp 595.000 (×3.5)\n' +
        '   → Profit/hari: ± Rp 19.833\n\n' +
        '💎 *Platinum* — Rp 300.000\n' +
        '   → Kembali: Rp 1.050.000 (×3.5)\n' +
        '   → Profit/hari: ± Rp 35.000\n\n' +
        '👑 *Diamond* — Rp 400.000\n' +
        '   → Kembali: Rp 1.600.000 (×4.0)\n' +
        '   → Profit/hari: ± Rp 53.333\n\n' +
        '━━━━━━━━━━━━━━━━━━━━\n' +
        '⏰ *DURASI:* 30 hari\n' +
        '💰 *PROFIT:* otomatis masuk saldo utama tiap hari\n' +
        '✅ *WITHDRAW:* bisa kapan saja setelah profit masuk',
      followUp: 'Anda tertarik paket yang mana?',
      options: ['Starter', 'Silver', 'Gold', 'Diamond']
    },

    // ---------- BONUS / REFERRAL ----------
    {
      id: 'bonus_referral',
      topic: 'bonus_referral',
      match: [
        'kode referral', 'kode reff', 'kode ref', 'referral code',
        'kode ajak', 'cara referral', 'cara dapat bonus', 'cara dapat komisi'
      ],
      patterns: [
        /\b(cara|gimana|gmn|bagaimana|bgmn|dapat|dapet|dapetin|dapatkan)\b.{0,20}\b(bonus|komisi|referral|reff|kode\s*referral|kode\s*reff)\b/i,
        /\b(kode|kodenya)\b.{0,20}\b(referral|reff|ref|ajak|ajakan|teman)\b/i
      ],
      reply: () =>
        'Siap, ini info program referral 🎁\n\n' +
        '━━━━━━━━━━━━━━━━━━━━\n' +
        '🎉 *BONUS PROGRAM:*\n' +
        '━━━━━━━━━━━━━━━━━━━━\n\n' +
        '💰 *Bonus Pendaftar Baru:* Rp 15.000\n' +
        '   _(otomatis saat daftar)_\n\n' +
        '💰 *Bonus Referral:* Rp 10.000 / orang\n' +
        '   _(untuk yang mengajak)_\n\n' +
        '💰 *Bonus User Baru via Referral:* Rp 5.000\n' +
        '   _(tambahan untuk yang daftar pakai kode)_\n\n' +
        '━━━━━━━━━━━━━━━━━━━━\n' +
        '📋 *CARA DAPAT KODE REFERRAL:*\n' +
        '━━━━━━━━━━━━━━━━━━━━\n\n' +
        '*1.* Login dashboard\n\n' +
        '*2.* Buka menu *"Referral"*\n\n' +
        '*3.* Kode referral Anda tertera di sana\n\n' +
        '*4.* Copy & bagikan ke teman\n\n' +
        '*5.* Bonus masuk otomatis ketika teman daftar\n\n' +
        '━━━━━━━━━━━━━━━━━━━━\n' +
        '💡 *TIPS:*\n' +
        '━━━━━━━━━━━━━━━━━━━━\n\n' +
        '• Bagikan link referral ke grup WA/Telegram\n' +
        '• Semakin banyak yang daftar, semakin banyak bonus\n' +
        '• Bonus TIDAK ada batas maksimal!',
      followUp: 'Anda mau lihat berapa bonus yang sudah terkumpul?',
      options: ['Cek bonus saya', 'Cara pakai kode', 'Info lebih lanjut']
    },

    // ---------- KONTAK ADMIN ----------
    {
      id: 'kontak_admin',
      topic: 'kontak_admin',
      match: [
        'kontak admin', 'hubungi admin', 'chat admin', 'telegram admin',
        'wa admin', 'whatsapp admin', 'nomor admin', 'adminnya',
        'admin dong', 'admin mana', 'mana admin', 'butuh admin',
        'mau tanya admin', 'mau chat admin'
      ],
      patterns: [
        /\b(kontak|hubungi|chat|wa|whatsapp|telegram|nomor|no\s*hp|dm)\b.{0,20}\b(admin|cs|customer\s*service|min|mimin)\b/i,
        /\b(admin|cs|min|mimin|adminnya|csnya)\b.{0,20}\b(mana|dimana|di\s*mana|kontaknya|nomornya|wa\s*nya|telegram\s*nya)\b/i,
        /\b(mau|ingin|pengen|butuh|perlu)\b.{0,20}\b(chat|kontak|hubungi|tanya|dm)\b.{0,20}\b(admin|cs|min|mimin)\b/i
      ],
      reply: () =>
        'Siap, ini kontak admin kami 📞\n\n' +
        '━━━━━━━━━━━━━━━━━━━━\n' +
        '👨‍💼 *KONTAK ADMIN:*\n' +
        '━━━━━━━━━━━━━━━━━━━━\n\n' +
        '📱 *Telegram:* ' + CS_TELEGRAM + '\n\n' +
        '⏰ *Jam Operasional:*\n' +
        '   Setiap hari: 09.00 - 22.00 WIB\n\n' +
        '━━━━━━━━━━━━━━━━━━━━\n' +
        '📝 *SEBELUM CHAT ADMIN, SIAPKAN:*\n' +
        '━━━━━━━━━━━━━━━━━━━━\n\n' +
        '*Untuk masalah saldo/topup:*\n' +
        '• Screenshot bukti bayar\n' +
        '• ID transaksi\n' +
        '• Username akun\n\n' +
        '*Untuk masalah withdraw:*\n' +
        '• ID withdraw (WD-xxxx)\n' +
        '• Screenshot riwayat\n\n' +
        '*Untuk masalah login/akun:*\n' +
        '• Username akun\n' +
        '• Screenshot error\n\n' +
        '*Untuk masalah investasi:*\n' +
        '• ID investasi\n' +
        '• Screenshot menu investasi\n\n' +
        '_Semakin lengkap info, semakin cepat admin bantu._',
      followUp: 'Ada yang bisa saya bantu lagi selain kontak admin?',
      options: ['Cek saldo', 'Cek withdraw', 'Cek bonus']
    },

    // ---------- SAPAAN ----------
    {
      id: 'sapaan',
      topic: 'sapaan',
      match: [
        'halo', 'hai', 'hallo', 'hello', 'helo', 'hi',
        'pagi', 'siang', 'sore', 'malam',
        'assalamualaikum', 'assalam', 'permisi', 'woi', 'oy', 'bos', 'bro', 'sis', 'gan'
      ],
      patterns: [
        /^(halo|hai|hallo|hello|helo|hi|pagi|siang|sore|malam|assalamualaikum|assalam|permisi|woi|oy|bos|bro|sis|gan)\b/i
      ],
      reply: () =>
        'Halo! 👋 Selamat datang di *Fast Trader*.\n\n' +
        'Saya CS otomatis yang siap bantu 24/7.\n\n' +
        '━━━━━━━━━━━━━━━━━━━━\n' +
        '💡 *PILIH TOPIK:*\n' +
        '━━━━━━━━━━━━━━━━━━━━\n\n' +
        '• 💳 Topup saldo\n' +
        '• 💸 Withdraw / penarikan\n' +
        '• 📈 Investasi & paket\n' +
        '• 🎁 Bonus & referral\n' +
        '• 🔐 Login / password\n' +
        '• ⚠️ Error / masalah\n' +
        '• 📞 Kontak admin\n\n' +
        'Ketik topik di atas, atau pilih tombol cepat di bawah 👇',
      followUp: 'Ada yang bisa saya bantu hari ini?',
      options: ['Cara topup', 'Cara withdraw', 'Paket investasi', 'Bonus referral']
    },

    // ---------- TERIMA KASIH ----------
    {
      id: 'thanks',
      topic: 'thanks',
      match: [
        'terima kasih', 'thanks', 'thank you', 'makasih', 'mksh',
        'thx', 'tq', 'syukron', 'tengkyu'
      ],
      patterns: [
        /\b(terima\s*kasih|makasih|mksh|thanks|thank\s*you|thx|tq|syukron|tengkyu)\b/i
      ],
      reply: () =>
        'Sama-sama! 😊\n\n' +
        'Senang bisa membantu Anda.\n\n' +
        'Kalau ada pertanyaan lain, jangan ragu chat lagi ya!\n\n' +
        'Semoga sukses & profit terus di Fast Trader 🚀💰',
      followUp: null,
      options: ['Ada lagi', 'Selesai']
    },

    // ---------- CARA DAFTAR ----------
    {
      id: 'daftar',
      topic: 'cara_daftar',
      match: [
        'cara daftar', 'cara register', 'mau daftar', 'pengen daftar',
        'ingin daftar', 'buat akun', 'buat akun baru', 'registrasi'
      ],
      patterns: [
        /\b(cara|gimana|gmn|bagaimana|bgmn|gmana|caranya|mau|pengen|pingin|ingin)\b.{0,20}\b(daftar|register|registrasi|signup|sign\s*up|buat\s*akun)\b/i
      ],
      reply: () =>
        'Siap, ini cara daftar akun baru 📝\n\n' +
        '━━━━━━━━━━━━━━━━━━━━\n' +
        '📋 *LANGKAH DAFTAR:*\n' +
        '━━━━━━━━━━━━━━━━━━━━\n\n' +
        '*1.* Klik menu *"Daftar"* di halaman utama\n\n' +
        '*2.* Isi form:\n' +
        '   • Username (huruf kecil, tanpa spasi)\n' +
        '   • Email aktif\n' +
        '   • Password (min 6 karakter)\n\n' +
        '*3.* _(Opsional)_ Masukkan kode referral\n' +
        '   → Dapat bonus tambahan Rp 5.000\n\n' +
        '*4.* Klik *"Daftar"*\n\n' +
        '*5.* Login otomatis\n\n' +
        '━━━━━━━━━━━━━━━━━━━━\n' +
        '🎁 *BONUS PENDAFTAR:*\n' +
        '━━━━━━━━━━━━━━━━━━━━\n\n' +
        '💰 Rp 15.000 langsung masuk saldo Anda!\n\n' +
        '_Bonus ini bisa dipakai untuk beli paket investasi._',
      followUp: 'Anda sudah punya kode referral dari teman?',
      options: ['Punya kode', 'Tidak punya', 'Belum tahu']
    },

    // ---------- INFO PROFIT ----------
    {
      id: 'info_profit',
      topic: 'info_profit',
      match: [
        'keuntungan', 'untung', 'profit', 'cuan', 'hasil', 'return', 'bunga',
        'berapa untungnya', 'berapa profitnya'
      ],
      patterns: [
        /\b(berapa|brp|brapa)\b.{0,20}\b(untung|profit|cuan|hasil|return|bunga|keuntungan)\b/i,
        /\b(info|detail|jelasin|jelaskan|kayak\s*mana|gimana\s*sih)\b.{0,20}\b(untung|profit|cuan|return)\b/i
      ],
      reply: () =>
        'Siap, saya jelaskan estimasi keuntungan 💰\n\n' +
        '━━━━━━━━━━━━━━━━━━━━\n' +
        '📊 *CONTOH PROFIT:*\n' +
        '━━━━━━━━━━━━━━━━━━━━\n\n' +
        'Contoh paket *Silver* (Rp 120.000):\n' +
        '• Multiplier: ×3.0\n' +
        '• Total kembali: *Rp 360.000*\n' +
        '• Profit / hari: *Rp 12.000*\n' +
        '• Durasi: *30 hari*\n\n' +
        '━━━━━━━━━━━━━━━━━━━━\n' +
        '💡 *TABEL CEPAT:*\n' +
        '━━━━━━━━━━━━━━━━━━━━\n\n' +
        '• Rp 65.000 → ×2.0 → Rp 130.000\n' +
        '• Rp 120.000 → ×3.0 → Rp 360.000\n' +
        '• Rp 170.000 → ×3.5 → Rp 595.000\n' +
        '• Rp 400.000 → ×4.0 → Rp 1.600.000\n\n' +
        '━━━━━━━━━━━━━━━━━━━━\n' +
        '✅ *KEUNTUNGAN:*\n' +
        '━━━━━━━━━━━━━━━━━━━━\n\n' +
        '• Profit otomatis masuk tiap hari\n' +
        '• Masuk ke saldo utama\n' +
        '• Bisa di-WD kapan saja\n' +
        '• Tidak perlu kerja apa-apa\n\n' +
        'Ketik "paket investasi" untuk info lengkap.',
      followUp: 'Mau tahu estimasi profit untuk paket tertentu?',
      options: ['Starter', 'Silver', 'Gold', 'Diamond']
    }
  ];

  const FALLBACK_REPLY =
    'Maaf, saya belum sepenuhnya paham pertanyaan Anda 🙏\n\n' +
    '━━━━━━━━━━━━━━━━━━━━\n' +
    '💡 *COBA KETIK TOPIK INI:*\n' +
    '━━━━━━━━━━━━━━━━━━━━\n\n' +
    '• "cara topup" — info topup saldo\n' +
    '• "cara withdraw" — info penarikan\n' +
    '• "paket investasi" — daftar paket\n' +
    '• "bonus referral" — program bonus\n' +
    '• "login gagal" — masalah login\n' +
    '• "saldo belum masuk" — saldo bermasalah\n' +
    '• "kontak admin" — kontak admin\n\n' +
    '━━━━━━━━━━━━━━━━━━━━\n' +
    '📞 *ATAU HUBUNGI ADMIN:*\n' +
    '━━━━━━━━━━━━━━━━━━━━\n\n' +
    'Telegram: ' + CS_TELEGRAM + '\n' +
    'Jam operasional: 09.00 - 22.00 WIB';

  // ============================================================
  // DRAG STATE
  // ============================================================
  const dragState = {
    isDragging: false,
    hasDragged: false,
    startX: 0,
    startY: 0,
    offsetX: 0,
    offsetY: 0,
    fabX: 0,
    fabY: 0
  };

  let fabEl = null;
  let panelEl = null;

  // ============================================================
  // FAB POSITION HELPERS
  // ============================================================
  function getFabSize() {
    return { w: 60, h: 60 };
  }

  function clampPosition(x, y) {
    const { w, h } = getFabSize();
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const pad = DRAG.EDGE_PADDING;
    return {
      x: Math.max(pad, Math.min(vw - w - pad, x)),
      y: Math.max(pad, Math.min(vh - h - pad, y))
    };
  }

  function applyFabPosition(x, y) {
    if (!fabEl) return;
    const pos = clampPosition(x, y);
    dragState.fabX = pos.x;
    dragState.fabY = pos.y;
    fabEl.style.transform = 'translate3d(' + pos.x + 'px, ' + pos.y + 'px, 0)';
    updatePanelPosition();
  }

  function savePosition() {
    try {
      localStorage.setItem(POS_KEY, JSON.stringify({
        x: dragState.fabX,
        y: dragState.fabY
      }));
    } catch (e) {}
  }

  function loadPosition() {
    try {
      const raw = localStorage.getItem(POS_KEY);
      if (!raw) return null;
      const pos = JSON.parse(raw);
      if (typeof pos.x === 'number' && typeof pos.y === 'number') return pos;
    } catch (e) {}
    return null;
  }

  function getDefaultPosition() {
    const { w, h } = getFabSize();
    return {
      x: window.innerWidth - w - DRAG.SNAP_MARGIN,
      y: window.innerHeight - h - DRAG.SNAP_MARGIN - 60
    };
  }

  function updatePanelPosition() {
    if (!panelEl || !fabEl) return;
    const panelW = 360;
    const panelH = 520;
    const fabSize = getFabSize();
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const margin = 8;

    let panelX = dragState.fabX + fabSize.w - panelW;
    let panelY = dragState.fabY - panelH - 12;

    if (panelX < margin) panelX = dragState.fabX;
    if (panelX + panelW > vw - margin) panelX = vw - panelW - margin;
    if (panelY < margin) panelY = dragState.fabY + fabSize.h + 12;
    if (panelY + panelH > vh - margin) panelY = vh - panelH - margin;

    panelX = Math.max(margin, panelX);
    panelY = Math.max(margin, panelY);

    panelEl.style.left = panelX + 'px';
    panelEl.style.top = panelY + 'px';
    panelEl.style.right = 'auto';
    panelEl.style.bottom = 'auto';
  }

  // ============================================================
  // DRAG HANDLERS
  // ============================================================
  function getPoint(e) {
    if (e.touches && e.touches.length > 0) {
      return { x: e.touches[0].clientX, y: e.touches[0].clientY };
    }
    if (e.changedTouches && e.changedTouches.length > 0) {
      return { x: e.changedTouches[0].clientX, y: e.changedTouches[0].clientY };
    }
    return { x: e.clientX, y: e.clientY };
  }

  function onPointerDown(e) {
    if (!fabEl) return;
    if (e.button !== undefined && e.button !== 0) return;

    const pt = getPoint(e);
    dragState.isDragging = true;
    dragState.hasDragged = false;
    dragState.startX = pt.x;
    dragState.startY = pt.y;
    dragState.offsetX = pt.x - dragState.fabX;
    dragState.offsetY = pt.y - dragState.fabY;

    fabEl.classList.add('cs-dragging');
    document.body.style.userSelect = 'none';

    document.addEventListener('pointermove', onPointerMove);
    document.addEventListener('pointerup', onPointerUp);
    document.addEventListener('pointercancel', onPointerUp);

    try { e.preventDefault(); } catch (_) {}
  }

  function onPointerMove(e) {
    if (!dragState.isDragging) return;
    const pt = getPoint(e);
    const dx = pt.x - dragState.startX;
    const dy = pt.y - dragState.startY;

    if (!dragState.hasDragged) {
      const dist = Math.sqrt(dx * dx + dy * dy);
      if (dist > DRAG.DRAG_THRESHOLD) {
        dragState.hasDragged = true;
      }
    }

    const newX = pt.x - dragState.offsetX;
    const newY = pt.y - dragState.offsetY;
    const pos = clampPosition(newX, newY);

    dragState.fabX = pos.x;
    dragState.fabY = pos.y;
    fabEl.style.transform = 'translate3d(' + pos.x + 'px, ' + pos.y + 'px, 0)';
    updatePanelPosition();

    try { e.preventDefault(); } catch (_) {}
  }

  function onPointerUp(e) {
    if (!dragState.isDragging) return;
    dragState.isDragging = false;

    if (fabEl) fabEl.classList.remove('cs-dragging');
    document.body.style.userSelect = '';

    document.removeEventListener('pointermove', onPointerMove);
    document.removeEventListener('pointerup', onPointerUp);
    document.removeEventListener('pointercancel', onPointerUp);

    if (dragState.hasDragged) {
      snapToEdge();
      savePosition();
    } else {
      togglePanel();
    }
  }

  function snapToEdge() {
    if (!DRAG.SNAP_TO_EDGE || !fabEl) return;
    const { w } = getFabSize();
    const vw = window.innerWidth;
    const margin = DRAG.SNAP_MARGIN;

    const distLeft = dragState.fabX + w / 2;
    const distRight = vw - (dragState.fabX + w / 2);

    const targetX = distLeft < distRight ? margin : vw - w - margin;

    fabEl.classList.add('cs-snapping');
    dragState.fabX = targetX;
    fabEl.style.transform = 'translate3d(' + targetX + 'px, ' + dragState.fabY + 'px, 0)';
    updatePanelPosition();

    setTimeout(() => {
      if (fabEl) fabEl.classList.remove('cs-snapping');
    }, 300);
  }

  function handleResize() {
    if (!fabEl) return;
    applyFabPosition(dragState.fabX, dragState.fabY);
  }

  // ============================================================
  // STATE
  // ============================================================
  let history = [];
  let isOpen = false;
  let customRepliesLoaded = false;
  let context = { lastTopic: null, lastIntent: null, ts: null };

  // ============================================================
  // STORAGE
  // ============================================================
  function loadHistory() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      history = raw ? JSON.parse(raw) : [];
      if (!Array.isArray(history)) history = [];
    } catch (e) { history = []; }

    try {
      const ctxRaw = localStorage.getItem(CONTEXT_KEY);
      if (ctxRaw) {
        const ctx = JSON.parse(ctxRaw);
        if (ctx && ctx.ts && Date.now() - ctx.ts < 10 * 60 * 1000) {
          context = ctx;
        }
      }
    } catch (e) {}

    if (history.length === 0) {
      history.push({
        sender: 'bot',
        text: 'Halo! 👋 Saya ' + CS_NAME + '.\n\nAda yang bisa saya bantu hari ini?\n\nKetik pertanyaan Anda, atau pilih topik cepat di bawah.\n\n_(Tips: tombol ini bisa digeser ke mana saja lho!)_',
        ts: Date.now()
      });
      saveHistory();
    }
  }

  function saveHistory() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(history.slice(-80)));
    } catch (e) {}
  }

  function saveContext() {
    try {
      localStorage.setItem(CONTEXT_KEY, JSON.stringify(context));
    } catch (e) {}
  }

  // ============================================================
  // LOAD CUSTOM REPLIES
  // ============================================================
  async function loadCustomReplies() {
    if (customRepliesLoaded) return;
    try {
      const res = await fetch('/api/cs/autoreplies', { credentials: 'same-origin' });
      if (!res.ok) return;
      const json = await res.json();
      if (json && json.success && Array.isArray(json.data) && json.data.length > 0) {
        const custom = json.data.map(r => {
          const kw = (r.keyword || '').toLowerCase().trim();
          const escaped = kw.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
          return {
            id: 'custom_' + kw,
            topic: 'custom_' + kw,
            match: [kw],
            patterns: [new RegExp('\\b' + escaped + '\\b', 'i')],
            reply: function () { return r.reply || ''; },
            isCustom: true
          };
        }).filter(r => r.match[0] && r.reply);
        AUTO_REPLIES = custom.concat(AUTO_REPLIES);
        customRepliesLoaded = true;
      }
    } catch (e) {}
  }

  // ============================================================
  // MATCHING
  // ============================================================
  function normalize(text) {
    return ' ' + String(text || '')
      .toLowerCase()
      .replace(/[^\w\s\u00C0-\u024F]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim() + ' ';
  }

  function matchesKeyword(normalizedText, keyword) {
    if (!keyword) return false;
    const k = String(keyword).toLowerCase().trim()
      .replace(/[^\w\s\u00C0-\u024F]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
    if (!k) return false;
    return normalizedText.includes(' ' + k + ' ');
  }

  function matchesPattern(rawText, patterns) {
    if (!Array.isArray(patterns)) return false;
    for (const p of patterns) {
      try {
        if (p instanceof RegExp && p.test(rawText)) return true;
      } catch (e) {}
    }
    return false;
  }

  function findRule(userText) {
    const rawText = String(userText || '').trim();
    if (!rawText) return null;
    const normalizedText = normalize(rawText);

    let bestRule = null;
    let bestScore = 0;
    let bestIndex = Infinity;

    for (let i = 0; i < AUTO_REPLIES.length; i++) {
      const rule = AUTO_REPLIES[i];
      let score = 0;

      if (matchesPattern(rawText, rule.patterns)) score += 1000;

      const keywords = Array.isArray(rule.match) ? rule.match : [];
      for (const kw of keywords) {
        if (matchesKeyword(normalizedText, kw)) {
          score += 10 + String(kw).length;
        }
      }

      if (context.lastTopic && rule.topic === context.lastTopic && score > 0) {
        score += 50;
      }

      if (score > 0) {
        if (score > bestScore || (score === bestScore && i < bestIndex)) {
          bestScore = score;
          bestRule = rule;
          bestIndex = i;
        }
      }
    }

    return bestRule;
  }

  function renderReply(rule) {
    if (!rule) return FALLBACK_REPLY;
    if (typeof rule.reply === 'function') return rule.reply();
    return rule.reply || FALLBACK_REPLY;
  }

  // ============================================================
  // RENDER HELPERS
  // ============================================================
  function escapeHtml(s) {
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function formatText(text) {
    let safe = escapeHtml(text);
    safe = safe.replace(/\*([^*\n]+?)\*/g, '<b>$1</b>');
    safe = safe.replace(/_([^_\n]+?)_/g, '<i>$1</i>');
    safe = safe.replace(/\n/g, '<br>');
    return safe;
  }

  function formatTime(ts) {
    try {
      const d = new Date(ts || Date.now());
      return d.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
    } catch (e) { return ''; }
  }

  function renderMessages() {
    const body = document.getElementById('cs-body');
    if (!body) return;
    body.innerHTML = '';
    history.forEach(m => {
      const div = document.createElement('div');
      div.className = 'cs-msg ' + (m.sender === 'user' ? 'user' : 'bot');
      div.innerHTML = formatText(m.text || '') + '<span class="cs-time">' + formatTime(m.ts) + '</span>';
      body.appendChild(div);
    });
    body.scrollTop = body.scrollHeight;
  }

  function renderQuickOptions(options) {
    const quick = document.getElementById('cs-quick');
    if (!quick) return;

    if (!Array.isArray(options) || options.length === 0) {
      quick.innerHTML = [
        '<button type="button" data-q="Cara topup">Topup</button>',
        '<button type="button" data-q="Cara withdraw">Withdraw</button>',
        '<button type="button" data-q="Paket investasi">Investasi</button>',
        '<button type="button" data-q="Bonus referral">Bonus</button>',
        '<button type="button" data-q="Kontak admin">Hubungi Admin</button>'
      ].join('');
    } else {
      quick.innerHTML = options.map(o =>
        '<button type="button" data-q="' + escapeHtml(o) + '">' + escapeHtml(o) + '</button>'
      ).join('');
    }

    quick.querySelectorAll('button').forEach(btn => {
      btn.addEventListener('click', function () {
        sendMessage(btn.dataset.q);
      });
    });
  }

  // ============================================================
  // SEND MESSAGE
  // ============================================================
  function sendMessage(text) {
    const clean = String(text || '').trim();
    if (!clean) return;

    history.push({ sender: 'user', text: clean, ts: Date.now() });
    saveHistory();
    renderMessages();

    const body = document.getElementById('cs-body');
    if (!body) return;

    const typing = document.createElement('div');
    typing.className = 'cs-msg bot typing';
    typing.textContent = 'CS sedang mengetik...';
    body.appendChild(typing);
    body.scrollTop = body.scrollHeight;

    const rule = findRule(clean);
    const reply = renderReply(rule);
    const delay = 700 + Math.random() * 900;

    if (rule && rule.topic) {
      context.lastTopic = rule.topic;
      context.ts = Date.now();
      saveContext();
    }

    setTimeout(function () {
      if (typing.parentNode) typing.parentNode.removeChild(typing);
      history.push({ sender: 'bot', text: reply, ts: Date.now() });
      saveHistory();
      renderMessages();

      if (rule && Array.isArray(rule.options) && rule.options.length > 0) {
        renderQuickOptions(rule.options);
      } else {
        renderQuickOptions(null);
      }

      if (!isOpen) showBadge();
    }, delay);
  }

  // ============================================================
  // UI BUILD
  // ============================================================
  function buildUI() {
    if (document.getElementById('cs-fab')) return;

    // FAB
    fabEl = document.createElement('button');
    fabEl.id = 'cs-fab';
    fabEl.type = 'button';
    fabEl.setAttribute('aria-label', 'Chat Customer Service (bisa digeser)');
    fabEl.innerHTML = '💬<span class="cs-badge">1</span>';
    document.body.appendChild(fabEl);

    // Panel
    panelEl = document.createElement('div');
    panelEl.id = 'cs-panel';
    panelEl.setAttribute('role', 'dialog');
    panelEl.setAttribute('aria-label', 'Customer Service Chat');
    panelEl.innerHTML = [
      '<div class="cs-header">',
      '  <div class="cs-avatar">🎧</div>',
      '  <div class="cs-info">',
      '    <b>' + escapeHtml(CS_NAME) + '</b>',
      '    <small>' + escapeHtml(CS_STATUS) + '</small>',
      '  </div>',
      '  <button class="cs-close" type="button" aria-label="Tutup">✕</button>',
      '</div>',
      '<div class="cs-body" id="cs-body"></div>',
      '<div class="cs-quick" id="cs-quick">',
      '  <button type="button" data-q="Cara topup">Topup</button>',
      '  <button type="button" data-q="Cara withdraw">Withdraw</button>',
      '  <button type="button" data-q="Paket investasi">Investasi</button>',
      '  <button type="button" data-q="Bonus referral">Bonus</button>',
      '  <button type="button" data-q="Kontak admin">Hubungi Admin</button>',
      '</div>',
      '<div class="cs-footer">',
      '  <input id="cs-input" type="text" placeholder="Ketik pesan..." autocomplete="off" />',
      '  <button id="cs-send" type="button" aria-label="Kirim">➤</button>',
      '</div>'
    ].join('');
    document.body.appendChild(panelEl);

    // Init position
    const saved = loadPosition();
    const pos = saved || getDefaultPosition();
    requestAnimationFrame(function () { applyFabPosition(pos.x, pos.y); });

    // Bind drag
    fabEl.addEventListener('pointerdown', onPointerDown);

    // Panel close
    panelEl.querySelector('.cs-close').addEventListener('click', closePanel);

    // Input
    const input = panelEl.querySelector('#cs-input');
    const sendBtn = panelEl.querySelector('#cs-send');

    function doSend() {
      const val = input.value;
      if (!val.trim()) return;
      input.value = '';
      sendMessage(val);
    }

    sendBtn.addEventListener('click', doSend);
    input.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); doSend(); }
    });

    // Quick buttons
    panelEl.querySelectorAll('.cs-quick button').forEach(function (btn) {
      btn.addEventListener('click', function () {
        sendMessage(btn.dataset.q);
      });
    });

    // Esc
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && isOpen) closePanel();
    });

    // Resize & scroll
    window.addEventListener('resize', handleResize);
    window.addEventListener('orientationchange', handleResize);
    window.addEventListener('scroll', function () {
      if (isOpen) updatePanelPosition();
    }, { passive: true });
  }

  // ============================================================
  // OPEN / CLOSE
  // ============================================================
  function togglePanel() {
    if (isOpen) closePanel();
    else openPanel();
  }

  function openPanel() {
    isOpen = true;
    if (panelEl) {
      updatePanelPosition();
      panelEl.classList.add('open');
    }
    clearBadge();
    try { sessionStorage.setItem(OPEN_KEY, '1'); } catch (e) {}
    setTimeout(function () {
      const inp = document.getElementById('cs-input');
      if (inp && window.innerWidth > 640) inp.focus();
    }, 150);
  }

  function closePanel() {
    isOpen = false;
    if (panelEl) panelEl.classList.remove('open');
    try { sessionStorage.setItem(OPEN_KEY, '0'); } catch (e) {}
  }

  function showBadge() {
    if (fabEl) fabEl.classList.add('has-new');
  }

  function clearBadge() {
    if (fabEl) fabEl.classList.remove('has-new');
  }

  // ============================================================
  // INIT
  // ============================================================
  async function init() {
    loadHistory();
    buildUI();
    renderMessages();

    try {
      if (sessionStorage.getItem(OPEN_KEY) === '1') {
        setTimeout(openPanel, 250);
      }
    } catch (e) {}

    window.addEventListener('storage', function (e) {
      if (e.key === STORAGE_KEY) {
        loadHistory();
        renderMessages();
      }
    });

    loadCustomReplies();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();