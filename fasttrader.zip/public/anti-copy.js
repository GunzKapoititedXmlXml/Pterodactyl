// anti-copy.js — proteksi browser + anti-crawler (mobile-safe)
(function () {
    'use strict';

    // ============================================================
    // 1. DETEKSI CRAWLER / HEADLESS BROWSER
    // ============================================================
    const ua = navigator.userAgent.toLowerCase();
    const isCrawler =
        // HTTP client
        /curl|wget|python|httpie|go-http|java\/|okhttp|node-fetch|axios|postman|insomnia/i.test(ua) ||
        // Scraper
        /scrapy|httrack|webcopier|webzip|websucker|teleport|grabber/i.test(ua) ||
        // SEO crawler
        /ahrefs|semrush|mj12|majestic|dotbot|screaming|seznam|baiduspider|yandex|sogou|exabot/i.test(ua) ||
        // Generic
        /bot|crawler|spider|scraper|harvest/i.test(ua) ||
        // Headless
        /headlesschrome|phantomjs|slimerjs|puppeteer|playwright/i.test(ua);

    // Deteksi headless browser modern (Chrome headless biasanya punya tanda ini)
    const isHeadless =
        navigator.webdriver === true ||
        (navigator.plugins && navigator.plugins.length === 0 && !/mobile/i.test(ua)) ||
        (navigator.languages && navigator.languages.length === 0);

    // Deteksi curl/wget yang pakai UA palsu (tapi tidak punya fitur browser)
    const noBrowserFeatures =
        typeof window.chrome === 'undefined' &&
        /chrome|chromium/i.test(ua);

    if (isCrawler || isHeadless || noBrowserFeatures) {
        // Ganti isi halaman dengan pesan kosong — crawler tidak dapat apa-apa
        document.documentElement.innerHTML = '<html><body style="background:#0a0e1a"></body></html>';
        // Stop eksekusi
        throw new Error('Blocked');
    }

    // ============================================================
    // 2. DISABLE RIGHT-CLICK
    // ============================================================
    document.addEventListener('contextmenu', e => e.preventDefault());

    // ============================================================
    // 3. DISABLE F12, Ctrl+U, Ctrl+S, Ctrl+Shift+I/J/C
    // ============================================================
    document.addEventListener('keydown', e => {
        if (e.key === 'F12') { e.preventDefault(); return false; }
        if (e.ctrlKey || e.metaKey) {
            const k = e.key.toLowerCase();
            if (k === 'u' || k === 's') { e.preventDefault(); return false; }
            if (e.shiftKey && (k === 'i' || k === 'j' || k === 'c')) {
                e.preventDefault(); return false;
            }
        }
    });

    // ============================================================
    // 4. DISABLE DRAG IMAGE
    // ============================================================
    document.addEventListener('dragstart', e => {
        if (e.target.tagName === 'IMG') e.preventDefault();
    });

    // ============================================================
    // 5. CONSOLE WARNING
    // ============================================================
    console.log('%c⚠️ STOP!', 'color:#ff3b30;font-size:48px;font-weight:bold;text-shadow:2px 2px 0 #000');
    console.log('%cJangan paste apapun di sini. Ini bisa menyebabkan akun Anda dicuri.', 'color:#ff9500;font-size:16px;font-weight:bold');
})();