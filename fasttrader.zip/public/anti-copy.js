// anti-copy.js — proteksi HTML dari orang awam (mobile-safe)
(function () {
    'use strict';

    // 1. Disable right-click
    document.addEventListener('contextmenu', e => e.preventDefault());

    // 2. Disable F12, Ctrl+U, Ctrl+S, Ctrl+Shift+I/J/C
    document.addEventListener('keydown', e => {
        if (e.key === 'F12') { e.preventDefault(); return false; }
        if (e.ctrlKey || e.metaKey) {
            const k = e.key.toLowerCase();
            if (k === 'u' || k === 's') { e.preventDefault(); return false; }
            if (e.shiftKey && (k === 'i' || k === 'j' || k === 'c')) {
                e.preventDefault(); return false;
            }
        }
    });

    // 3. Disable drag image
    document.addEventListener('dragstart', e => {
        if (e.target.tagName === 'IMG') e.preventDefault();
    });

    // 4. Console warning (tidak blokir halaman)
    console.log(
        '%c⚠️ STOP!',
        'color:#ff3b30;font-size:48px;font-weight:bold;text-shadow:2px 2px 0 #000'
    );
    console.log(
        '%cJangan paste apapun di sini. Ini bisa menyebabkan akun Anda dicuri.',
        'color:#ff9500;font-size:16px;font-weight:bold'
    );
})();