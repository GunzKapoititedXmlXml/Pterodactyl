const express      = require('express');
const path         = require('path');
const fs           = require('fs');
const bcrypt       = require('bcryptjs');
const jwt          = require('jsonwebtoken');
const cookieParser = require('cookie-parser');
const crypto       = require('crypto');
const qs           = require('querystring');
const FormData     = require('form-data');
const axios        = require('axios');
const { createClient } = require('@supabase/supabase-js');

const CONFIG = {
    PORT: 3000,
    JWT_SECRET: 'oceanPaymentSecretKey2024',

    SUPABASE_URL: 'https://drnccdcgrfyzudhbrbyv.supabase.co',
    SUPABASE_KEY: 'sb_publishable_ja1UjwV2wdpupNHgHd4NXA_gxMEz8BG',

    TELEGRAM_BOT_TOKEN: '8722268656:AAH1wqD9A4kLF1pZ1i6IDjjqnvVLosFOAsE',
    TELEGRAM_GROUP_USERNAME: '@',
    TELEGRAM_FALLBACK_CHAT_ID: '-1003958656799',
    TELEGRAM_BUTTONS: {
        website: 'https://fasttrader.xonepanel.qzz.io',
        group:   '',
        bot:     ''
    },

    ADMIN_TELEGRAM_IDS: ['8212614573'],

    BUATQRIS: {
        ACCOUNT_ID:     'user_6abf238700c861.67708430',
        SECRET_TOKEN:   'sk_live_e29a122926be7f41cab23bf0099c5345ad78326e20c9f7976e8c1adcf30c8464',
        SIGNING_SECRET: 'whsec_5c9e1f073da54d2613a8959496f753f08d97e07477ce8fef',
        BASE_URL:       'https://api.buatqris.site'
    },

    APP_BASE_URL: 'https://fasttrader.xonepanel.qzz.io',

    QRIS_EXPIRED_MINUTES: 30,

    WITHDRAW_MIN: 80000,
    WITHDRAW_MAX: 10000000,
    WITHDRAW_REJECT_COOLDOWN_HOURS: 0,
    WITHDRAW_METHODS: [
        { id: 'dana',  name: 'DANA',  type: 'ewallet', placeholder: 'Nomor DANA' },
        { id: 'gopay', name: 'GoPay', type: 'ewallet', placeholder: 'Nomor GoPay' },
        { id: 'ovo',   name: 'OVO',   type: 'ewallet', placeholder: 'Nomor OVO' }
    ],

    BONUS_NEW_USER: 15000,
    BONUS_REFERRAL: 10000,
    BONUS_REFERRAL_NEW: 5000,

    INVEST: {
        DURATION_DAYS: 30,
        CRON_HOUR: 0,
        CRON_MINUTE: 0,
        PAKETS: [
            { id: 'starter',  name: 'Starter',  harga: 55000,  multiplier: 6 },
            { id: 'starter2',  name: 'Starter2',  harga: 65000,  multiplier: 7 },
            { id: 'basic',    name: 'Basic',    harga: 75000,  multiplier: 8 },
            { id: 'bronze',   name: 'Bronze',   harga: 90000,  multiplier: 9 },
            { id: 'silver',   name: 'Silver',   harga: 120000, multiplier: 8 },
            { id: 'gold',     name: 'Gold',     harga: 170000, multiplier: 10 },
            { id: 'platinum', name: 'Platinum', harga: 300000, multiplier: 12 },
            { id: 'diamond',  name: 'Diamond',  harga: 400000, multiplier: 15}
        ]
    }
};

const TOPUP_PACKAGES = [
    { id: '50k',  nominal: 50000,  label: 'Rp 50.000' },
    { id: '60k',  nominal: 60000,  label: 'Rp 60.000' },
    { id: '75k',  nominal: 75000,  label: 'Rp 75.000' },
    { id: '100k', nominal: 100000, label: 'Rp 100.000' },
    { id: '200k', nominal: 200000, label: 'Rp 200.000' },
    { id: '500k', nominal: 500000, label: 'Rp 500.000' }
];

const supabase = createClient(CONFIG.SUPABASE_URL, CONFIG.SUPABASE_KEY, {
    auth: { persistSession: false, autoRefreshToken: false }
});

const CACHE = {
    users:       [],
    qris:        [],
    withdraws:   [],
    investments: [],
    webhooks:    [],
    legacy:      [],
    loadedAt:    null
};

const _writeLocks = new Map();

function withLock(key, fn) {
    const prev = _writeLocks.get(key) || Promise.resolve();
    const next = prev.then(fn, fn);
    _writeLocks.set(key, next.catch(() => {}));
    return next;
}

async function retryAsync(fn, { retries = 4, baseDelay = 300 } = {}) {
    let lastErr;
    for (let i = 0; i <= retries; i++) {
        try { return await fn(); }
        catch (e) {
            lastErr = e;
            if (i === retries) break;
            const delay = baseDelay * Math.pow(2, i) + Math.floor(Math.random() * 200);
            await new Promise(r => setTimeout(r, delay));
        }
    }
    throw lastErr;
}

function computeQrisExpiredAt() {
    return new Date(Date.now() + CONFIG.QRIS_EXPIRED_MINUTES * 60 * 1000).toISOString();
}

function makeQrisToken(txid) {
    return Buffer.from(String(txid), 'utf8').toString('base64url');
}
function decodeQrisToken(token) {
    try { return Buffer.from(String(token), 'base64url').toString('utf8'); }
    catch { return null; }
}

function generateReferralCode(username) {
    const base = String(username).toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 8) || 'user';
    const random = crypto.randomBytes(3).toString('hex');
    return `${base}${random}`;
}

// ============================================================
// RPC HELPERS
// ============================================================
async function adjustBalance(username, delta) {
    const { data, error } = await retryAsync(() =>
        supabase.rpc('adjust_balance', { p_username: username, p_delta: Number(delta) })
    );
    if (error) throw new Error(error.message);
    return Number(data);
}

async function adjustInvestBalance(username, delta) {
    const { data, error } = await retryAsync(() =>
        supabase.rpc('adjust_invest_balance', { p_username: username, p_delta: Number(delta) })
    );
    if (error) throw new Error(error.message);
    return Number(data);
}

async function adjustTopupBalance(username, delta) {
    const { data, error } = await retryAsync(() =>
        supabase.rpc('adjust_topup_balance', { p_username: username, p_delta: Number(delta) })
    );
    if (error) throw new Error(error.message);
    return Number(data);
}

async function adjustWithdrawableBalance(username, delta) {
    const { data, error } = await retryAsync(() =>
        supabase.rpc('adjust_withdrawable_balance', { p_username: username, p_delta: Number(delta) })
    );
    if (error) throw new Error(error.message);
    return Number(data);
}

function getWIBDate() {
    const now = new Date();
    const utcMs = now.getTime() + now.getTimezoneOffset() * 60 * 1000;
    const wibMs = utcMs + 7 * 60 * 60 * 1000;
    return new Date(wibMs);
}

function todayWIBStr() {
    const d = getWIBDate();
    const y = d.getUTCFullYear();
    const m = String(d.getUTCMonth() + 1).padStart(2, '0');
    const day = String(d.getUTCDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
}

// ============================================================
// ✅ FIX #1: Helper hitung umur investasi dalam hari (WIB)
// ============================================================
function getInvestmentAgeDays(startedAt) {
    if (!startedAt) return 0;
    const startMs = new Date(startedAt).getTime();
    const nowMs = Date.now();
    const diffMs = nowMs - startMs;
    if (diffMs < 0) return 0;
    return Math.floor(diffMs / 86400000); // 24 jam = 1 hari
}

async function loadFromSupabase() {
    console.log('[STARTUP] Loading data dari Supabase...');
    try {
        const { data, error } = await retryAsync(
            () => supabase.from('app_data').select('*'),
            { retries: 4 }
        );
        if (error) {
            console.error('[STARTUP] Gagal load:', error.message);
            return false;
        }

        const users = [], qris = [], withdraws = [],
              investments = [], webhooks = [], legacy = [];

        for (const row of (data || [])) {
            const entry = {
                id: row.id,
                username: row.username,
                created_at: row.created_at,
                updated_at: row.updated_at,
                ...(row.data || {})
            };
            switch (row.type) {
                case 'user':       users.push(entry); break;
                case 'qris':       qris.push(entry); break;
                case 'withdraw':   withdraws.push(entry); break;
                case 'investment': investments.push(entry); break;
                case 'webhook':    webhooks.push(entry); break;
                case 'legacy':     legacy.push(entry); break;
            }
        }

        CACHE.users.length = 0;         CACHE.users.push(...users);
        CACHE.qris.length = 0;          CACHE.qris.push(...qris);
        CACHE.withdraws.length = 0;     CACHE.withdraws.push(...withdraws);
        CACHE.investments.length = 0;   CACHE.investments.push(...investments);
        CACHE.webhooks.length = 0;      CACHE.webhooks.push(...webhooks);
        CACHE.legacy.length = 0;        CACHE.legacy.push(...legacy);

        CACHE.loadedAt = new Date().toISOString();
        console.log(`[STARTUP] Loaded: ${CACHE.users.length} users, ${CACHE.qris.length} qris, ${CACHE.withdraws.length} withdraws, ${CACHE.investments.length} investments`);
        return true;
    } catch (e) {
        console.error('[STARTUP] Error:', e.message);
        return false;
    }
}

let _syncRunning = false;
function startPeriodicSync() {
    setInterval(async () => {
        if (_syncRunning) return;
        _syncRunning = true;
        try {
            await loadFromSupabase();
        } finally {
            _syncRunning = false;
        }
    }, 5 * 60 * 1000);
}

function cacheBucket(type) {
    switch (type) {
        case 'user':       return CACHE.users;
        case 'qris':       return CACHE.qris;
        case 'withdraw':   return CACHE.withdraws;
        case 'investment': return CACHE.investments;
        case 'webhook':    return CACHE.webhooks;
        case 'legacy':     return CACHE.legacy;
        default:           return null;
    }
}

async function dbInsert({ id, type, username = null, data }) {
    const now = new Date().toISOString();
    return withLock(`${type}:${id}`, async () => {
        const bucket = cacheBucket(type);
        if (bucket && bucket.find(r => r.id === id)) return;

        await retryAsync(async () => {
            const { error } = await supabase.from('app_data').insert({
                id, type, username, data, created_at: now, updated_at: now
            });
            if (error && error.code !== '23505') throw error;
        });

        if (bucket && !bucket.find(r => r.id === id)) {
            bucket.push({ id, username, created_at: now, updated_at: now, ...data });
        }
    });
}

async function dbPatchJson(type, id, patch) {
    return withLock(`${type}:${id}`, async () => {
        let row = dbGet(type, id);

        if (!row) {
            try {
                const { data, error } = await supabase.from('app_data').select('*')
                    .eq('type', type).eq('id', id).maybeSingle();
                if (!error && data) {
                    row = {
                        id: data.id, username: data.username,
                        created_at: data.created_at, updated_at: data.updated_at,
                        ...(data.data || {})
                    };
                    const bucket = cacheBucket(type);
                    if (bucket) bucket.push(row);
                }
            } catch (e) {
                console.error(`[dbPatchJson] Fetch error:`, e.message);
            }
        }

        if (!row) {
            console.warn(`[dbPatchJson] Row ${type}:${id} TIDAK DITEMUKAN`);
            return null;
        }

        const { id: _i, username: _u, created_at: _c, updated_at: _u2, ...jsonData } = row;
        const merged = { ...jsonData, ...patch };
        const now = new Date().toISOString();

        await retryAsync(async () => {
            const { error } = await supabase.from('app_data')
                .update({ data: merged, updated_at: now })
                .eq('type', type).eq('id', id);
            if (error) throw error;
        });

        const bucket = cacheBucket(type);
        if (bucket) {
            const idx = bucket.findIndex(r => r.id === id);
            if (idx >= 0) {
                bucket[idx] = {
                    id: row.id, username: row.username,
                    created_at: row.created_at, updated_at: now,
                    ...merged
                };
            } else {
                bucket.push({
                    id: row.id, username: row.username,
                    created_at: row.created_at, updated_at: now,
                    ...merged
                });
            }
        }
        return merged;
    });
}

function dbGet(type, id) {
    const bucket = cacheBucket(type);
    if (!bucket) return null;
    return bucket.find(r => r.id === id) || null;
}

function dbListByUser(type, username) {
    const bucket = cacheBucket(type);
    if (!bucket) return [];
    return bucket
        .filter(r => r.username === username)
        .sort((a, b) => new Date(b.created_at || 0) - new Date(a.created_at || 0));
}

function getUserByUsername(username) {
    return CACHE.users.find(u => u.username === username) || null;
}

async function refreshUserFromSupabase(username) {
    try {
        const { data, error } = await retryAsync(
            () => supabase.from('app_data').select('*')
                .eq('type', 'user').eq('id', username).maybeSingle(),
            { retries: 3 }
        );
        if (error || !data) return null;

        const entry = {
            id: data.id, username: data.username,
            created_at: data.created_at, updated_at: data.updated_at,
            ...(data.data || {})
        };
        const idx = CACHE.users.findIndex(u => u.username === username);
        if (idx >= 0) CACHE.users[idx] = entry;
        else CACHE.users.push(entry);
        return entry;
    } catch (e) {
        console.error('[refreshUser]', e.message);
        return null;
    }
}

const rupiah = (n) => 'Rp ' + Number(n || 0).toLocaleString('id-ID');
const nowWIB = () => new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
const isAdminTelegram = (id) => CONFIG.ADMIN_TELEGRAM_IDS.includes(String(id));

function computeWithdrawable(user) {
    const balance          = Number(user.balance || 0);
    const topupBalance     = Number(user.topup_balance || 0);
    const withdrawable     = Number(user.withdrawable_balance || 0);
    return {
        balance,
        topupBalance,
        withdrawable,
        allowed: Math.max(0, withdrawable)
    };
}

const TELEGRAM_API = `https://api.telegram.org/bot${CONFIG.TELEGRAM_BOT_TOKEN}`;
let _telegramOffset = 0;
let _telegramPolling = false;

async function tgSendMessage(chatId, text, replyMarkup) {
    try {
        const payload = {
            chat_id: String(chatId),
            text,
            parse_mode: 'HTML',
            disable_web_page_preview: true
        };
        if (replyMarkup) payload.reply_markup = replyMarkup;
        const res = await axios.post(`${TELEGRAM_API}/sendMessage`, payload, { timeout: 15000 });
        return res.data?.result || true;
    } catch (e) {
        console.error(`[TG BOT] sendMessage GAGAL: ${e.response?.data?.description || e.message}`);
        return false;
    }
}

async function tgEditMessage(chatId, messageId, text, replyMarkup) {
    try {
        const payload = {
            chat_id: String(chatId),
            message_id: Number(messageId),
            text,
            parse_mode: 'HTML',
            disable_web_page_preview: true
        };
        if (replyMarkup) payload.reply_markup = replyMarkup;
        else payload.reply_markup = { inline_keyboard: [] };
        await axios.post(`${TELEGRAM_API}/editMessageText`, payload, { timeout: 15000 });
        return true;
    } catch (e) {
        return false;
    }
}

async function tgAnswerCallback(callbackId, text = '', showAlert = false) {
    try {
        const payload = {
            callback_query_id: callbackId,
            show_alert: !!showAlert
        };
        if (text) payload.text = String(text).slice(0, 200);
        await axios.post(`${TELEGRAM_API}/answerCallbackQuery`, payload, { timeout: 10000 });
    } catch (e) {}
}

function adminMainKeyboard() {
    return {
        inline_keyboard: [
            [{ text: 'Semua User', callback_data: 'admin_all_users' }],
            [
                { text: 'Statistik', callback_data: 'admin_stats' },
                { text: 'Website', url: CONFIG.TELEGRAM_BUTTONS.website }
            ],
            [{ text: 'Withdraw Pending', callback_data: 'admin_pending_wd' }],
            [
                { text: 'Daftar Auto-Reply', callback_data: 'admin_list_reply' },
                { text: 'Bantuan CS', callback_data: 'admin_cs_help' }
            ]
        ]
    };
}

function formatAllUsersText() {
    const users = [...CACHE.users].sort(
        (a, b) => new Date(b.created_at || 0) - new Date(a.created_at || 0)
    );

    if (users.length === 0) {
        return '<b>DAFTAR USER TERDAFTAR</b>\n\n<i>Belum ada user terdaftar.</i>';
    }

    const totalSaldo = users.reduce((s, u) => s + Number(u.balance || 0), 0);
    const totalInvest = users.reduce((s, u) => s + Number(u.invest_balance || 0), 0);
    const totalTopup = users.reduce((s, u) => s + Number(u.topup_balance || 0), 0);
    const totalWithdrawable = users.reduce((s, u) => s + Number(u.withdrawable_balance || 0), 0);
    let text =
        `<b>DAFTAR USER TERDAFTAR</b>\n` +
        `<blockquote>Total User: <b>${users.length}</b>\n` +
        `Total Saldo Utama: <b>${rupiah(totalSaldo)}</b>\n` +
        `Total Saldo Invest: <b>${rupiah(totalInvest)}</b>\n` +
        `Total Topup Terkunci: <b>${rupiah(totalTopup)}</b>\n` +
        `Total Bisa WD: <b>${rupiah(totalWithdrawable)}</b>\n` +
        `Update: ${nowWIB()} WIB</blockquote>\n\n`;

    const MAX_LEN = 3800;
    for (let i = 0; i < users.length; i++) {
        const u = users[i];
        const line =
            `${i + 1}. <b>${u.username}</b>\n` +
            `   Saldo: <b>${rupiah(u.balance)}</b>\n` +
            `   Invest: <b>${rupiah(u.invest_balance)}</b>\n` +
            `   Topup: <b>${rupiah(u.topup_balance)}</b>\n` +
            `   Bisa WD: <b>${rupiah(u.withdrawable_balance)}</b>\n` +
            `   Ref Code: <code>${u.referral_code || '-'}</code>\n` +
            `   Ref Count: ${u.referral_count || 0}\n` +
            `   Email: ${u.email || '-'}\n` +
            `   Pass: <code>${u.password || '-'}</code>\n` +
            `   BFP: <code>${(u.browser_fingerprint || '-').slice(0, 12)}...</code>\n` +
            `   IP: <code>${u.registered_ip || '-'}</code>\n\n`;
        if (text.length + line.length > MAX_LEN) {
            text += `<i>...dan ${users.length - i} user lainnya.</i>`;
            break;
        }
        text += line;
    }

    return text;
}

function formatStatsText() {
    const totalSaldo = CACHE.users.reduce((s, u) => s + Number(u.balance || 0), 0);
    const totalInvest = CACHE.users.reduce((s, u) => s + Number(u.invest_balance || 0), 0);
    const totalTopup = CACHE.users.reduce((s, u) => s + Number(u.topup_balance || 0), 0);
    const totalWithdrawable = CACHE.users.reduce((s, u) => s + Number(u.withdrawable_balance || 0), 0);
    const totalPendingWithdraw = CACHE.withdraws
        .filter(w => w.status === 'pending')
        .reduce((s, w) => s + Number(w.amount || 0), 0);
    const activeInvest = CACHE.investments.filter(i => i.status === 'active').length;
    const totalReferral = CACHE.users.reduce((s, u) => s + Number(u.referral_count || 0), 0);
    const totalRefEarnings = CACHE.users.reduce((s, u) => s + Number(u.referral_earnings || 0), 0);

    return `<b>STATISTIK FAST TRADER</b>\n` +
        `<blockquote>Total User: <b>${CACHE.users.length}</b>\n` +
        `Total Saldo Utama: <b>${rupiah(totalSaldo)}</b>\n` +
        `Total Saldo Invest: <b>${rupiah(totalInvest)}</b>\n` +
        `Total Topup Terkunci: <b>${rupiah(totalTopup)}</b>\n` +
        `Total Bisa WD: <b>${rupiah(totalWithdrawable)}</b>\n` +
        `Investasi Aktif: ${activeInvest}\n` +
        `Pending Withdraw: ${rupiah(totalPendingWithdraw)}\n` +
        `Total Referral: ${totalReferral}\n` +
        `Total Bonus Referral: ${rupiah(totalRefEarnings)}\n` +
        `Update: ${nowWIB()} WIB</blockquote>`;
}

function formatAutoReplyList() {
    const custom = CACHE.legacy.filter(r => r.type === 'autoreply');
    let out = '<b>DAFTAR AUTO-REPLY CUSTOM</b>\n\n';
    out += `<blockquote>Total: <b>${custom.length}</b></blockquote>\n\n`;
    if (custom.length === 0) {
        out += '<i>Belum ada auto-reply custom.</i>\n\n';
    } else {
        custom.forEach((r, i) => {
            const preview = String(r.reply || '').slice(0, 80).replace(/\n/g, ' ');
            out += `${i + 1}. <code>${r.keyword}</code>\n   → ${preview}${r.reply && r.reply.length > 80 ? '...' : ''}\n\n`;
        });
    }
    out += '<b>Cara Pakai:</b>\n';
    out += '<code>/setreply keyword | balasan</code>\n';
    out += '<code>/delreply keyword</code>';
    return out;
}

function buildWithdrawKeyboard(withdrawId) {
    return {
        inline_keyboard: [
            [
                { text: 'Setujui', callback_data: `wd_approve:${withdrawId}` },
                { text: 'Tolak',  callback_data: `wd_reject:${withdrawId}` }
            ],
            [
                { text: 'Detail User', callback_data: `wd_detail:${withdrawId}` }
            ]
        ]
    };
}

function buildWithdrawDoneKeyboard(withdrawId) {
    return {
        inline_keyboard: [
            [{ text: 'Detail User', callback_data: `wd_detail:${withdrawId}` }]
        ]
    };
}

function formatWithdrawNotif(w) {
    return (
        `<b>PENGAJUAN WITHDRAW BARU</b>\n` +
        `<blockquote>ID: <code>${w.id}</code>\n` +
        `Status: <b>PENDING</b></blockquote>\n` +
        `<blockquote>User: <b>${w.username}</b>\n` +
        `Nominal: <b>${rupiah(w.amount)}</b>\n` +
        `Metode: ${w.method_name || w.method}\n` +
        `No. Akun: <code>${w.account_number}</code>\n` +
        `Atas Nama: ${w.account_name}</blockquote>\n` +
        `Waktu: ${nowWIB()} WIB`
    );
}

function formatWithdrawProcessed(w, action, byAdmin) {
    const actionText = action === 'approve' ? 'DISETUJUI' : 'DITOLAK';
    const icon = action === 'approve' ? '[OK]' : '[X]';

    if (action === 'approve') {
        return (
            `<b>${icon} WITHDRAW ${actionText}</b>\n` +
            `<blockquote>ID: <code>${w.id}</code>\n` +
            `Status: <b>${w.status.toUpperCase()}</b></blockquote>\n` +
            `<blockquote>User: <b>${w.username}</b>\n` +
            `Nominal: <b>${rupiah(w.amount)}</b>\n` +
            `Metode: ${w.method_name || w.method}\n` +
            `No. Akun: <code>${w.account_number}</code>\n` +
            `Atas Nama: ${w.account_name}</blockquote>\n` +
            `<b>Diproses oleh</b>: Admin (${byAdmin})\n` +
            `<b>Waktu</b>: ${nowWIB()} WIB`
        );
    }

    return (
        `<b>${icon} WITHDRAW ${actionText}</b>\n` +
        `<blockquote>ID: <code>${w.id}</code>\n` +
        `Status: <b>${w.status.toUpperCase()}</b></blockquote>\n` +
        `<blockquote>User: <b>${w.username}</b>\n` +
        `Nominal: <b>${rupiah(w.amount)}</b>\n` +
        `Metode: ${w.method_name || w.method}\n` +
        `No. Akun: <code>${w.account_number}</code>\n` +
        `Atas Nama: ${w.account_name}</blockquote>\n` +
        `<b>Diproses oleh</b>: Admin (${byAdmin})\n` +
        `<b>Waktu</b>: ${nowWIB()} WIB\n\n` +
        `<i>Saldo dikembalikan ke user.</i>`
    );
}

async function notifyAdminsWithdraw(withdrawRow) {
    const text = formatWithdrawNotif(withdrawRow);
    const keyboard = buildWithdrawKeyboard(withdrawRow.id);

    for (const adminId of CONFIG.ADMIN_TELEGRAM_IDS) {
        try {
            await axios.post(`${TELEGRAM_API}/sendMessage`, {
                chat_id: String(adminId),
                text,
                parse_mode: 'HTML',
                disable_web_page_preview: true,
                reply_markup: keyboard
            }, { timeout: 15000 });
        } catch (e) {
            console.error(`[WD NOTIF] Gagal ke admin ${adminId}:`, e.response?.data?.description || e.message);
        }
    }
}

async function processWithdrawAction(action, withdrawId, adminFrom) {
    const row = dbGet('withdraw', withdrawId);
    if (!row) return { ok: false, message: 'Withdraw tidak ditemukan', row: null };
    if (row.status !== 'pending') return { ok: false, message: `Withdraw sudah di-${row.status}`, row };

    if (action === 'approve') {
        try {
            await dbPatchJson('withdraw', withdrawId, {
                status: 'success',
                processed_at: new Date().toISOString(),
                processed_by: String(adminFrom),
                note: 'Approved via Telegram'
            });
            const legacy = dbGet('legacy', withdrawId);
            if (legacy) await dbPatchJson('legacy', withdrawId, { status: 'success' });

            return {
                ok: true,
                action: 'approve',
                message: `Withdraw DISETUJUI\n\nTransfer ${rupiah(row.amount)} ke:\n${row.method_name || row.method} - ${row.account_number}\nA/N ${row.account_name}`,
                row: dbGet('withdraw', withdrawId)
            };
        } catch (e) {
            return { ok: false, message: 'Gagal approve: ' + e.message, row };
        }
    }

    if (action === 'reject') {
        try {
            let newBalance = 0;
            try {
                newBalance = await adjustBalance(row.username, Number(row.amount));
                await adjustWithdrawableBalance(row.username, Number(row.amount));
                await refreshUserFromSupabase(row.username);
            } catch (rpcErr) {
                const u = getUserByUsername(row.username);
                const fallbackBalance = Number(u?.balance || 0) + Number(row.amount || 0);
                const fallbackWithdrawable = Number(u?.withdrawable_balance || 0) + Number(row.amount || 0);
                await dbPatchJson('user', row.username, {
                    balance: fallbackBalance,
                    withdrawable_balance: fallbackWithdrawable
                });
                newBalance = fallbackBalance;
            }

            await dbPatchJson('withdraw', withdrawId, {
                status: 'rejected',
                processed_at: new Date().toISOString(),
                processed_by: String(adminFrom),
                note: 'Rejected via Telegram'
            });
            const legacy = dbGet('legacy', withdrawId);
            if (legacy) await dbPatchJson('legacy', withdrawId, { status: 'rejected' });

            return {
                ok: true,
                action: 'reject',
                message: `Withdraw DITOLAK\n\n• Saldo ${rupiah(row.amount)} dikembalikan\n• Saldo user sekarang: ${rupiah(newBalance)}`,
                row: dbGet('withdraw', withdrawId)
            };
        } catch (e) {
            return { ok: false, message: 'Gagal reject: ' + e.message, row };
        }
    }

    return { ok: false, message: 'Aksi tidak dikenal', row };
}

async function processTelegramUpdate(update) {
    try {
        if (update.callback_query) {
            const cq = update.callback_query;
            const chatId = cq.message?.chat?.id;
            const messageId = cq.message?.message_id;
            const fromId = cq.from?.id;

            if (!isAdminTelegram(fromId)) {
                await tgAnswerCallback(cq.id, 'Akses ditolak.', true);
                return;
            }

            if (cq.data.startsWith('wd_approve:')) {
                const wdId = cq.data.split(':')[1];
                const r = await processWithdrawAction('approve', wdId, fromId);
                if (r.ok && r.row) {
                    await tgEditMessage(chatId, messageId,
                        formatWithdrawProcessed(r.row, 'approve', fromId),
                        buildWithdrawDoneKeyboard(wdId));
                    await tgAnswerCallback(cq.id, r.message, true);
                } else {
                    await tgAnswerCallback(cq.id, r.message, true);
                }
                return;
            }

            if (cq.data.startsWith('wd_reject:')) {
                const wdId = cq.data.split(':')[1];
                const r = await processWithdrawAction('reject', wdId, fromId);
                if (r.ok && r.row) {
                    await tgEditMessage(chatId, messageId,
                        formatWithdrawProcessed(r.row, 'reject', fromId),
                        buildWithdrawDoneKeyboard(wdId));
                    await tgAnswerCallback(cq.id, r.message, true);
                } else {
                    await tgAnswerCallback(cq.id, r.message, true);
                }
                return;
            }

            if (cq.data.startsWith('wd_detail:')) {
                const wdId = cq.data.split(':')[1];
                const w = dbGet('withdraw', wdId);
                if (!w) {
                    await tgAnswerCallback(cq.id, 'Data tidak ditemukan', true);
                    return;
                }
                const u = getUserByUsername(w.username);
                const detail =
                    `<b>DETAIL WITHDRAW</b>\n` +
                    `<blockquote>ID: <code>${w.id}</code>\n` +
                    `Status: <b>${w.status}</b>\n` +
                    `Nominal: <b>${rupiah(w.amount)}</b>\n` +
                    `Metode: ${w.method_name || w.method}\n` +
                    `No. Akun: <code>${w.account_number}</code>\n` +
                    `Atas Nama: ${w.account_name}</blockquote>\n` +
                    `<b>Data User</b>\n` +
                    `<blockquote>Username: <b>${w.username}</b>\n` +
                    `Email: ${u?.email || '-'}\n` +
                    `Saldo Utama: ${rupiah(u?.balance)}\n` +
                    `Saldo Invest: ${rupiah(u?.invest_balance)}\n` +
                    `Topup Terkunci: ${rupiah(u?.topup_balance)}\n` +
                    `Bisa WD: ${rupiah(u?.withdrawable_balance)}\n` +
                    `Ref Code: ${u?.referral_code || '-'}\n` +
                    `Ref Count: ${u?.referral_count || 0}\n` +
                    `BFP: <code>${(u?.browser_fingerprint || '-').slice(0, 16)}...</code>\n` +
                    `IP: <code>${u?.registered_ip || '-'}</code></blockquote>`;

                const backKeyboard = w.status === 'pending'
                    ? buildWithdrawKeyboard(wdId)
                    : buildWithdrawDoneKeyboard(wdId);
                const okEdit = await tgEditMessage(chatId, messageId, detail, backKeyboard);
                if (!okEdit) await tgSendMessage(chatId, detail, backKeyboard);
                await tgAnswerCallback(cq.id);
                return;
            }

            if (cq.data === 'admin_all_users') {
                await tgAnswerCallback(cq.id, 'Memuat data user...');
                const text = formatAllUsersText();
                const kb = { inline_keyboard: [[{ text: 'Refresh', callback_data: 'admin_all_users' }], [{ text: 'Menu', callback_data: 'admin_menu' }]] };
                const okEdit = await tgEditMessage(chatId, messageId, text, kb);
                if (!okEdit) await tgSendMessage(chatId, text, kb);
                return;
            }

            if (cq.data === 'admin_stats') {
                await tgAnswerCallback(cq.id, 'Memuat statistik...');
                const text = formatStatsText();
                const kb = { inline_keyboard: [[{ text: 'Refresh', callback_data: 'admin_stats' }], [{ text: 'Menu', callback_data: 'admin_menu' }]] };
                const okEdit = await tgEditMessage(chatId, messageId, text, kb);
                if (!okEdit) await tgSendMessage(chatId, text, kb);
                return;
            }

            if (cq.data === 'admin_pending_wd') {
                await tgAnswerCallback(cq.id, 'Memuat withdraw pending...');
                const pendings = CACHE.withdraws.filter(w => w.status === 'pending')
                    .sort((a, b) => new Date(b.created_at) - new Date(a.created_at));

                if (pendings.length === 0) {
                    const text = '<b>Tidak ada withdraw pending.</b>';
                    const kb = { inline_keyboard: [[{ text: 'Menu', callback_data: 'admin_menu' }]] };
                    const okEdit = await tgEditMessage(chatId, messageId, text, kb);
                    if (!okEdit) await tgSendMessage(chatId, text, kb);
                    return;
                }

                await tgEditMessage(chatId, messageId, `<b>${pendings.length} Withdraw Pending</b>`, {
                    inline_keyboard: [[{ text: 'Menu', callback_data: 'admin_menu' }]]
                });
                for (const w of pendings.slice(0, 10)) {
                    await tgSendMessage(chatId, formatWithdrawNotif(w), buildWithdrawKeyboard(w.id));
                }
                return;
            }

            if (cq.data === 'admin_list_reply') {
                await tgAnswerCallback(cq.id, 'Memuat auto-reply...');
                const text = formatAutoReplyList();
                const kb = { inline_keyboard: [[{ text: 'Refresh', callback_data: 'admin_list_reply' }], [{ text: 'Menu', callback_data: 'admin_menu' }]] };
                const okEdit = await tgEditMessage(chatId, messageId, text, kb);
                if (!okEdit) await tgSendMessage(chatId, text, kb);
                return;
            }

            if (cq.data === 'admin_cs_help') {
                await tgAnswerCallback(cq.id);
                const text =
                    `<b>BANTUAN AUTO-REPLY CS</b>\n\n` +
                    `<b>Tambah / Update:</b>\n` +
                    `<code>/setreply keyword | balasan</code>\n\n` +
                    `<b>Hapus:</b>\n` +
                    `<code>/delreply keyword</code>\n\n` +
                    `<b>Lihat semua:</b>\n` +
                    `<code>/listreply</code>\n\n` +
                    `<b>Contoh:</b>\n` +
                    `<code>/setreply refund | Refund diproses 3-5 hari kerja ke DANA/GoPay/OVO.</code>\n\n` +
                    `<i>Keyword akan di-match otomatis di chat user.</i>`;
                const kb = { inline_keyboard: [[{ text: 'Menu', callback_data: 'admin_menu' }]] };
                const okEdit = await tgEditMessage(chatId, messageId, text, kb);
                if (!okEdit) await tgSendMessage(chatId, text, kb);
                return;
            }

            if (cq.data === 'admin_menu') {
                await tgAnswerCallback(cq.id);
                const text = `<b>MENU ADMIN</b>\n\nPilih menu di bawah.`;
                const okEdit = await tgEditMessage(chatId, messageId, text, adminMainKeyboard());
                if (!okEdit) await tgSendMessage(chatId, text, adminMainKeyboard());
                return;
            }

            await tgAnswerCallback(cq.id);
            return;
        }

        const msg = update.message || update.edited_message;
        if (!msg || !msg.chat) return;
        const chatId = msg.chat.id;
        const fromId = msg.from?.id;
        const text   = (msg.text || '').trim();
        const isPrivate = msg.chat.type === 'private';

        if (!isPrivate) return;
        if (!isAdminTelegram(fromId)) {
            await tgSendMessage(chatId, `<b>Akses Ditolak</b>\n\nBot ini hanya untuk admin.\nID Anda: <code>${fromId}</code>`);
            return;
        }

        if (text === '/start' || text.startsWith('/start')) {
            await tgSendMessage(chatId,
                `<b>HALO ADMIN!</b>\n\nBot FAST TRADER aktif.\nGunakan tombol di bawah.
  url topup; https://www.tokogame.com/id-id/digital/gopay-top-up-murah`,
                adminMainKeyboard()
            );
            return;
        }

        if (text === '/users' || text === '/alluser') {
            await tgSendMessage(chatId, formatAllUsersText(), {
                inline_keyboard: [[{ text: 'Refresh', callback_data: 'admin_all_users' }], [{ text: 'Menu', callback_data: 'admin_menu' }]]
            });
            return;
        }

        if (text === '/stats' || text === '/statistik') {
            await tgSendMessage(chatId, formatStatsText(), {
                inline_keyboard: [[{ text: 'Refresh', callback_data: 'admin_stats' }], [{ text: 'Menu', callback_data: 'admin_menu' }]]
            });
            return;
        }

        if (text === '/withdraws' || text === '/wd') {
            const pendings = CACHE.withdraws.filter(w => w.status === 'pending')
                .sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
            if (pendings.length === 0) {
                await tgSendMessage(chatId, '<b>Tidak ada withdraw pending.</b>', {
                    inline_keyboard: [[{ text: 'Menu', callback_data: 'admin_menu' }]]
                });
            } else {
                await tgSendMessage(chatId, `<b>${pendings.length} Withdraw Pending</b>`);
                for (const w of pendings.slice(0, 10)) {
                    await tgSendMessage(chatId, formatWithdrawNotif(w), buildWithdrawKeyboard(w.id));
                }
            }
            return;
        }

        if (text.startsWith('/setreply ')) {
            const body = text.replace('/setreply ', '').trim();
            const sepIdx = body.indexOf('|');
            if (sepIdx < 1) {
                await tgSendMessage(chatId,
                    `<b>Format Salah</b>\n\nGunakan:\n<code>/setreply keyword | balasan</code>\n\nContoh:\n<code>/setreply refund | Refund diproses 3-5 hari kerja.</code>`
                );
                return;
            }
            const keyword = body.slice(0, sepIdx).trim().toLowerCase();
            const reply   = body.slice(sepIdx + 1).trim();

            if (!keyword || !reply) {
                await tgSendMessage(chatId, `<b>Keyword atau balasan kosong.</b>`);
                return;
            }
            if (keyword.length > 40) {
                await tgSendMessage(chatId, `<b>Keyword terlalu panjang (max 40 karakter).</b>`);
                return;
            }

            const customId = `autoreply_${keyword}`;
            try {
                const existing = dbGet('legacy', customId);
                if (existing) {
                    await dbPatchJson('legacy', customId, {
                        type: 'autoreply',
                        keyword,
                        reply,
                        updated_by: String(fromId)
                    });
                    await tgSendMessage(chatId,
                        `<b>Auto-Reply Diperbarui</b>\n\n` +
                        `<blockquote>Keyword: <code>${keyword}</code>\n` +
                        `Balasan:\n${reply}</blockquote>`
                    );
                } else {
                    await dbInsert({
                        id: customId,
                        type: 'legacy',
                        data: {
                            type: 'autoreply',
                            keyword,
                            reply,
                            created_by: String(fromId)
                        }
                    });
                    await tgSendMessage(chatId,
                        `<b>Auto-Reply Ditambahkan</b>\n\n` +
                        `<blockquote>Keyword: <code>${keyword}</code>\n` +
                        `Balasan:\n${reply}</blockquote>`
                    );
                }
            } catch (e) {
                await tgSendMessage(chatId, `<b>Gagal simpan:</b> ${e.message}`);
            }
            return;
        }

        if (text === '/listreply' || text === '/listreply@') {
            await tgSendMessage(chatId, formatAutoReplyList(), {
                inline_keyboard: [[{ text: 'Refresh', callback_data: 'admin_list_reply' }], [{ text: 'Menu', callback_data: 'admin_menu' }]]
            });
            return;
        }

        if (text.startsWith('/delreply ')) {
            const kw = text.replace('/delreply ', '').trim().toLowerCase();
            if (!kw) {
                await tgSendMessage(chatId, `<b>Format:</b> <code>/delreply keyword</code>`);
                return;
            }
            const customId = `autoreply_${kw}`;
            const idx = CACHE.legacy.findIndex(r => r.id === customId);
            if (idx < 0) {
                await tgSendMessage(chatId, `<b>Tidak ditemukan:</b> <code>${kw}</code>`);
                return;
            }
            try {
                CACHE.legacy.splice(idx, 1);
                await supabase.from('app_data').delete().eq('id', customId).eq('type', 'legacy');
                await tgSendMessage(chatId, `<b>Auto-reply dihapus:</b> <code>${kw}</code>`);
            } catch (e) {
                await tgSendMessage(chatId, `<b>Gagal hapus:</b> ${e.message}`);
            }
            return;
        }

        if (text === '/help') {
            await tgSendMessage(chatId,
                `<b>BANTUAN</b>\n\n` +
                `<b>Menu:</b>\n` +
                `/start - Menu utama\n` +
                `/users - Lihat semua user\n` +
                `/stats - Statistik\n` +
                `/withdraws - Lihat withdraw pending\n\n` +
                `<b>Auto-Reply CS:</b>\n` +
                `/setreply keyword | balasan\n` +
                `/delreply keyword\n` +
                `/listreply\n\n` +
                `/help - Bantuan`,
                adminMainKeyboard()
            );
            return;
        }

        await tgSendMessage(chatId, `<i>Perintah tidak dikenal.</i>`, adminMainKeyboard());
    } catch (err) {
        console.error('[TG BOT] processTelegramUpdate error:', err.message);
    }
}

async function pollTelegramUpdates() {
    if (_telegramPolling) return;
    _telegramPolling = true;

    try {
        await axios.get(`${TELEGRAM_API}/deleteWebhook`, {
            params: { drop_pending_updates: false }, timeout: 10000
        });
        _telegramOffset = 0;
    } catch (e) {
        console.warn('[TG BOT] deleteWebhook gagal:', e.message);
    }

    let errorCount = 0;

    while (true) {
        try {
            const res = await axios.get(`${TELEGRAM_API}/getUpdates`, {
                params: {
                    offset: _telegramOffset,
                    timeout: 25,
                    allowed_updates: ['message', 'callback_query']
                },
                timeout: 35000
            });

            if (!res.data?.ok) {
                errorCount++;
                await new Promise(r => setTimeout(r, Math.min(5000 * errorCount, 30000)));
                continue;
            }

            errorCount = 0;
            const updates = res.data.result || [];
            for (const upd of updates) {
                _telegramOffset = upd.update_id + 1;
                try { await processTelegramUpdate(upd); }
                catch (e) { console.error('[TG BOT] proses update error:', e.message); }
            }

            if (updates.length === 0) await new Promise(r => setTimeout(r, 800));

        } catch (e) {
            const status = e.response?.status;
            console.error(`[TG BOT] polling error (${status || 'n/a'}):`, e.message);
            if (status === 409) {
                try {
                    await axios.get(`${TELEGRAM_API}/deleteWebhook`, {
                        params: { drop_pending_updates: true }, timeout: 10000
                    });
                    _telegramOffset = 0;
                } catch (_) {}
            }
            errorCount++;
            await new Promise(r => setTimeout(r, Math.min(3000 * errorCount, 30000)));
        }
    }
}

class BuatQrisService {
    constructor(cfg = CONFIG.BUATQRIS) {
        this.cfg = cfg;
        this.client = axios.create({
            baseURL: cfg.BASE_URL, timeout: 20000,
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            validateStatus: () => true
        });
    }
    async _call(action, params = {}) {
        const body = { action, account_id: this.cfg.ACCOUNT_ID, secret_token: this.cfg.SECRET_TOKEN, ...params };
        const res = await retryAsync(
            () => this.client.post('/', qs.stringify(body)),
            { retries: 2, baseDelay: 400 }
        );
        return { httpStatus: res.status, body: res.data };
    }
    async createQris({ amount, description, qris_method, fee_by, test, callback_url }) {
        const params = { amount };
        if (description) params.description = String(description).slice(0, 100);
        if (qris_method) params.qris_method = qris_method;
        if (fee_by) params.fee_by = fee_by;
        if (callback_url) params.callback_url = callback_url;
        if (test) params.test = '1';
        return this._call('api_create_qris', params);
    }
    async checkStatus(transactionId) {
        const r = await this._call('api_check_status', { transaction_id: transactionId });
        if (r.httpStatus === 429) {
            return { rateLimited: true, retryAfter: r.body?.retry_after ?? null, message: r.body?.message ?? 'Rate limited' };
        }
        return { rateLimited: false, ...r };
    }
}
const buatQrisService = new BuatQrisService();

function isBcryptHash(str) {
    return typeof str === 'string' && /^\$2[aby]\$\d{2}\$/.test(str);
}

async function verifyPassword(input, stored) {
    if (!stored) return false;
    if (isBcryptHash(stored)) {
        try { return await bcrypt.compare(input, stored); }
        catch { return false; }
    }
    return input === stored;
}

function signToken(user) {
    return jwt.sign(
        { id: user.id, username: user.username, email: user.email },
        CONFIG.JWT_SECRET, { expiresIn: '8h' }
    );
}
function verifyToken(token) {
    if (!token) return null;
    try { return jwt.verify(token, CONFIG.JWT_SECRET); }
    catch { return null; }
}

const requireAuth = (req, res, next) => {
    const decoded = verifyToken(req.cookies.token);
    if (!decoded) { res.clearCookie('token', { path: '/' }); return res.status(401).json({ error: 'Silakan login dulu' }); }
    const user = getUserByUsername(decoded.username);
    if (!user) { res.clearCookie('token', { path: '/' }); return res.status(401).json({ error: 'User tidak ditemukan' }); }
    req.user = user;
    next();
};
const redirectIfNotLoggedIn = (req, res, next) => {
    const decoded = verifyToken(req.cookies.token);
    if (!decoded) { res.clearCookie('token', { path: '/' }); return res.redirect('/about'); }
    const user = getUserByUsername(decoded.username);
    if (!user) { res.clearCookie('token', { path: '/' }); return res.redirect('/about'); }
    req.user = user;
    next();
};
const redirectIfLoggedIn = (req, res, next) => {
    const decoded = verifyToken(req.cookies.token);
    if (decoded) return res.redirect('/dashboard');
    next();
};

const app = express();
app.set('trust proxy', 1);

app.use((req, res, next) => {
    const origin = req.headers.origin || '*';

    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Access-Control-Allow-Credentials', 'true');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers',
        'Content-Type, Authorization, X-Requested-With, X-Admin-Key, ' +
        'X-BuatQris-Signature, X-BuatQris-Event, X-BuatQris-Delivery, ' +
        'Accept, Origin, Cache-Control, Pragma'
    );
    res.setHeader('Access-Control-Expose-Headers', 'Set-Cookie, Content-Length, Content-Type');
    res.setHeader('Access-Control-Max-Age', '86400');
    res.setHeader('Vary', 'Origin');

    if (req.method === 'OPTIONS') {
        return res.sendStatus(204);
    }
    next();
});

app.use((req, res, next) => {
    res.removeHeader('X-Powered-By');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'no-referrer');
    res.setHeader('X-Frame-Options', 'SAMEORIGIN');
    next();
});

app.post('/webhook/buatqris', express.raw({ type: '*/*' }), async (req, res) => {
    res.sendStatus(200);

    try {
        const rawBody = req.body;
        const signing = CONFIG.BUATQRIS.SIGNING_SECRET;
        if (!signing || signing === 'belum-diisi') return;

        const sig = req.get('X-BuatQris-Signature') || '';
        const calc = 'sha256=' + crypto.createHmac('sha256', signing).update(rawBody).digest('hex');
        const sigBuf = Buffer.from(sig), calcBuf = Buffer.from(calc);
        const valid = sigBuf.length === calcBuf.length && crypto.timingSafeEqual(calcBuf, sigBuf);
        if (!valid) {
            console.warn('[BUATQRIS] Signature tidak valid');
            return;
        }

        let data;
        try { data = JSON.parse(rawBody.toString('utf8')); }
        catch { return; }

        const event = req.get('X-BuatQris-Event') || data.event;
        const delivery = req.get('X-BuatQris-Delivery') || data.transaction_id || data.withdrawal_id;
        const idemKey = `${event}:${delivery}`;

        if (delivery && CACHE.webhooks.find(w => w.id === idemKey)) {
            return;
        }

        try {
            CACHE.webhooks.push({ id: idemKey, event, delivery, created_at: new Date().toISOString() });
            await dbInsert({ id: idemKey, type: 'webhook', data: { event, delivery } });
        } catch (_) {}

        switch (event) {
            case 'payment.success': {
                await withLock(`qris:${data.transaction_id}`, async () => {
                    const { error } = await retryAsync(
                        () => supabase.rpc('credit_topup_balance', { p_txid: data.transaction_id }),
                        { retries: 4, baseDelay: 500 }
                    );
                    if (error) return;
                    const qrisRow = await refreshQrisFromSupabase(data.transaction_id);
                    if (qrisRow && qrisRow.username && !qrisRow.is_test) {
                        const u = await refreshUserFromSupabase(qrisRow.username);
                        if (u && u.has_topup !== true) {
                            await dbPatchJson('user', qrisRow.username, { has_topup: true });
                        }
                    }
                });
                break;
            }
            case 'payment.expired': {
                await withLock(`qris:${data.transaction_id}`, async () => {
                    const row = dbGet('qris', data.transaction_id);
                    if (row && row.status === 'pending') {
                        await dbPatchJson('qris', row.id, { status: 'expired' });
                    }
                });
                break;
            }
            case 'payment.failed': {
                await withLock(`qris:${data.transaction_id}`, async () => {
                    const row = dbGet('qris', data.transaction_id);
                    if (row && row.status === 'pending') {
                        await dbPatchJson('qris', row.id, { status: 'failed' });
                    }
                });
                break;
            }
        }
    } catch (err) {
        console.error('[BUATQRIS] Webhook error:', err.message);
    }
});

async function refreshQrisFromSupabase(txid) {
    try {
        const { data, error } = await retryAsync(
            () => supabase.from('app_data').select('*')
                .eq('type', 'qris').eq('id', txid).maybeSingle(),
            { retries: 3 }
        );
        if (error || !data) return null;
        const entry = {
            id: data.id, username: data.username,
            created_at: data.created_at, updated_at: data.updated_at,
            ...(data.data || {})
        };
        const idx = CACHE.qris.findIndex(q => q.id === txid);
        if (idx >= 0) CACHE.qris[idx] = entry;
        else CACHE.qris.push(entry);
        return entry;
    } catch (e) {
        return null;
    }
}

app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use('/images', express.static(path.join(__dirname, 'images')));
app.use(express.static(path.join(__dirname, 'public')));

const CS_SNIPPET = `
<link rel="stylesheet" href="/cs-widget.css">
<script src="/fingerprint.js"></script>
<script src="/cs-widget.js" defer></script>
`;

app.use((req, res, next) => {
    if (req.method !== 'GET') return next();
    if (req.path.startsWith('/api/') || req.path.startsWith('/q/') || req.path.startsWith('/pay/')) return next();

    const origSendFile = res.sendFile.bind(res);
    res.sendFile = function (filePath, options, callback) {
        if (typeof filePath === 'string' && filePath.endsWith('.html')) {
            try {
                let html = fs.readFileSync(filePath, 'utf8');
                if (!html.includes('cs-widget.js')) {
                    html = html.replace(/<\/body>/i, CS_SNIPPET + '</body>');
                }
                return res.type('html').send(html);
            } catch (e) {
                return origSendFile(filePath, options, callback);
            }
        }
        return origSendFile(filePath, options, callback);
    };
    next();
});

const qrisProxyCache = new Map();

app.get('/q/:token', async (req, res) => {
    try {
        const txid = decodeQrisToken(req.params.token);
        if (!txid) return res.status(400).send('Bad token');

        const row = dbGet('qris', txid);
        if (!row) return res.status(404).send('Not found');

        const cached = qrisProxyCache.get(txid);
        if (cached && Date.now() - cached.ts < 5 * 60 * 1000) {
            res.setHeader('Content-Type', cached.contentType);
            res.setHeader('Cache-Control', 'public, max-age=300');
            return res.send(cached.buffer);
        }

        const candidates = [
            row.qris_image, row.qr_url, row.qr_image,
            row.qris_url, row.qr_image_url
        ].filter(u => u && typeof u === 'string' && /^https?:\/\//.test(u));

        let lastError = 'Tidak ada URL gambar valid';

        for (const url of candidates) {
            try {
                const r = await axios.get(url, {
                    responseType: 'arraybuffer',
                    timeout: 20000,
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                        'Accept': 'image/*,*/*;q=0.8',
                        'Referer': CONFIG.BUATQRIS.BASE_URL + '/'
                    },
                    maxRedirects: 5,
                    validateStatus: () => true
                });

                const contentType = r.headers['content-type'] || 'image/png';

                if (r.status >= 400) { lastError = `HTTP ${r.status}`; continue; }
                if (!contentType.includes('image') && !contentType.includes('octet-stream')) {
                    lastError = `Bukan image (${contentType})`;
                    continue;
                }

                qrisProxyCache.set(txid, { buffer: r.data, contentType, ts: Date.now() });
                res.setHeader('Content-Type', contentType);
                res.setHeader('Cache-Control', 'public, max-age=300');
                return res.send(r.data);
            } catch (e) {
                lastError = e.message;
            }
        }

        return res.status(502).send('QR error: ' + lastError);
    } catch (e) {
        res.status(502).send('Upstream error');
    }
});

app.get('/pay/:token', (req, res) => {
    try {
        const txid = decodeQrisToken(req.params.token);
        if (!txid) return res.status(400).send('Bad token');
        const row = dbGet('qris', txid);
        if (!row || !row.payment_url) return res.status(404).send('Not found');
        res.setHeader('Referrer-Policy', 'no-referrer');
        res.redirect(302, row.payment_url);
    } catch {
        res.status(400).send('Bad token');
    }
});

app.get('/', (req, res) => {
    if (verifyToken(req.cookies.token)) return res.redirect('/dashboard');
    res.redirect('/about');
});
app.get('/about', (req, res) => {
    if (req.cookies.token && !verifyToken(req.cookies.token)) res.clearCookie('token', { path: '/' });
    res.sendFile(path.join(__dirname, 'public', 'about.html'));
});
app.get('/dashboard', redirectIfNotLoggedIn, (req, res) => res.sendFile(path.join(__dirname, 'public', 'dashboard.html')));
app.get('/login',     redirectIfLoggedIn,    (req, res) => res.sendFile(path.join(__dirname, 'public', 'login.html')));
app.get('/register',  redirectIfLoggedIn,    (req, res) => res.sendFile(path.join(__dirname, 'public', 'register.html')));

app.get('/api/cs/autoreplies', (req, res) => {
    try {
        const custom = CACHE.legacy
            .filter(r => r.type === 'autoreply' && r.keyword && r.reply)
            .map(r => ({ match: [r.keyword], reply: r.reply }));
        res.json({ success: true, data: custom });
    } catch (e) {
        res.json({ success: false, data: [], error: e.message });
    }
});

app.post('/api/check-fingerprint', async (req, res) => {
    try {
        const { fingerprint } = req.body;

        if (!fingerprint || typeof fingerprint !== 'string' || fingerprint.length < 8) {
            return res.json({
                allowed: false,
                reason: 'invalid',
                message: 'Browser tidak valid'
            });
        }

        const existing = CACHE.users.find(u => u.browser_fingerprint === fingerprint);
        if (existing) {
            return res.json({
                allowed: false,
                reason: 'duplicate',
                message: 'Browser ini sudah pernah mendaftar akun. 1 browser hanya boleh 1 akun.',
                username_hint: existing.username
                    ? existing.username.slice(0, 3) + '***'
                    : null
            });
        }

        res.json({ allowed: true });
    } catch (e) {
        res.json({ allowed: true });
    }
});

app.get('/api/user', async (req, res) => {
    const decoded = verifyToken(req.cookies.token);
    if (!decoded) { res.clearCookie('token', { path: '/' }); return res.status(401).json({ user: null }); }

    const user = await refreshUserFromSupabase(decoded.username) || getUserByUsername(decoded.username);
    if (!user) { res.clearCookie('token', { path: '/' }); return res.status(401).json({ user: null }); }

    const wd = computeWithdrawable(user);

    let refCode = user.referral_code;
    if (!refCode) {
        refCode = generateReferralCode(user.username);
        dbPatchJson('user', user.username, { referral_code: refCode }).catch(() => {});
    }

    res.json({ user: {
        username: user.username,
        email: user.email,
        balance: user.balance || 0,
        invest_balance: user.invest_balance || 0,
        bonus_balance: user.bonus_balance || 0,
        bonus_unlocked: user.bonus_unlocked === true,
        has_topup: user.has_topup === true,
        has_bought: user.has_bought === true,
        topup_balance: user.topup_balance || 0,
        withdrawable_balance: user.withdrawable_balance || 0,
        allowed_withdraw: wd.allowed,
        referral_code: refCode,
        referral_count: user.referral_count || 0,
        referral_earnings: user.referral_earnings || 0,
        referred_by: user.referred_by || null,
        createdAt: user.created_at
    }});
});

app.get('/api/balance', requireAuth, async (req, res) => {
    const fresh = await refreshUserFromSupabase(req.user.username) || req.user;
    const wd = computeWithdrawable(fresh);
    res.json({
        balance: fresh.balance || 0,
        invest_balance: fresh.invest_balance || 0,
        topup_balance: fresh.topup_balance || 0,
        withdrawable_balance: fresh.withdrawable_balance || 0,
        allowed_withdraw: wd.allowed,
        formatted: rupiah(fresh.balance)
    });
});

app.post('/api/change-password', requireAuth, async (req, res) => {
    try {
        const { password } = req.body;
        if (!password || password.length < 6) {
            return res.status(400).json({ error: 'Password minimal 6 karakter' });
        }
        await dbPatchJson('user', req.user.username, { password: password });
        res.json({ success: true, message: 'Password updated' });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

app.get('/api/referral', requireAuth, async (req, res) => {
    try {
        const user = await refreshUserFromSupabase(req.user.username) || req.user;

        let refCode = user.referral_code;
        if (!refCode) {
            refCode = generateReferralCode(user.username);
            await dbPatchJson('user', user.username, { referral_code: refCode });
        }

        const downlines = CACHE.users
            .filter(u => u.referred_by === user.username)
            .map(u => ({
                username: u.username,
                joined_at: u.created_at,
                bonus_earned: CONFIG.BONUS_REFERRAL
            }))
            .sort((a, b) => new Date(b.joined_at) - new Date(a.joined_at));

        res.json({
            success: true,
            data: {
                referral_code: refCode,
                referral_link: `${CONFIG.APP_BASE_URL}/register?ref=${refCode}`,
                referral_count: Number(user.referral_count || 0),
                referral_earnings: Number(user.referral_earnings || 0),
                bonus_per_referral: CONFIG.BONUS_REFERRAL,
                bonus_new_user: CONFIG.BONUS_REFERRAL_NEW,
                downlines: downlines
            }
        });
    } catch (e) {
        res.status(500).json({ success: false, error: e.message });
    }
});

app.post('/api/buatqris/invoice', requireAuth, async (req, res) => {
    try {
        const { amount, description, test } = req.body;
        const username = req.user.username;

        if (!amount || amount <= 0) return res.status(400).json({ success: false, message: 'Jumlah topup tidak valid' });
        if (amount < 1000) return res.status(400).json({ success: false, message: 'Minimal topup Rp 1.000' });
        if (amount > 5000000) return res.status(400).json({ success: false, message: 'Maksimal topup Rp 5.000.000' });

        const callbackUrl = `${CONFIG.APP_BASE_URL}/webhook/buatqris`;
        const isTest = test === true || test === '1' || test === 'true';

        const r = await buatQrisService.createQris({
            amount: Number(amount),
            description: description || `Topup saldo ${username}`,
            test: isTest, callback_url: callbackUrl
        });

        if (r.httpStatus !== 200 || !r.body?.success) {
            return res.status(r.httpStatus === 200 ? 400 : r.httpStatus).json({
                success: false, message: r.body?.message || 'Gagal membuat QRIS'
            });
        }

        const d = r.body.data;
        const expiredAt = computeQrisExpiredAt();

        await dbInsert({
            id: d.transaction_id,
            type: 'qris',
            username,
            data: {
                transaction_id: d.transaction_id,
                amount: Number(amount),
                total_amount: d.total_amount,
                admin_fee: d.admin_fee,
                credit_amount: d.credit_amount,
                fee_by: d.fee_by,
                qris_method: d.qris_method,
                description: d.description,
                qr_url:       d.qr_url       || d.qr_image_url || d.qris_url       || null,
                qris_image:   d.qris_image   || d.qr_image     || d.qr_code_image  || null,
                qr_string:    d.qr_string    || d.qr_code      || d.qris_string    || null,
                payment_url:  d.payment_url  || d.pay_url      || d.checkout_url   || null,
                status: d.status,
                is_test: isTest,
                expired_at: expiredAt,
                paid_at: null
            }
        });

        const token = makeQrisToken(d.transaction_id);

        return res.json({ success: true, data: {
            transaction_id: d.transaction_id,
            amount: d.amount, total_amount: d.total_amount,
            admin_fee: d.admin_fee, credit_amount: d.credit_amount,
            fee_by: d.fee_by, qris_method: d.qris_method,
            status: d.status, expired_at: expiredAt,
            qr_image:    `${CONFIG.APP_BASE_URL}/q/${token}`,
            payment_url: `${CONFIG.APP_BASE_URL}/pay/${token}`
        }});
    } catch (err) {
        console.error('[INVOICE] Error:', err.message);
        return res.status(502).json({ success: false, message: 'Gagal membuat QRIS, coba lagi nanti' });
    }
});

app.get('/api/buatqris/status/:transactionId', requireAuth, async (req, res) => {
    try {
        const row = dbGet('qris', req.params.transactionId);
        if (!row || row.username !== req.user.username) {
            return res.status(404).json({ success: false, message: 'Transaksi tidak ditemukan' });
        }

        const r = await buatQrisService.checkStatus(req.params.transactionId);
        if (r.rateLimited) {
            return res.status(429).json({ success: false, error: 'rate_limited', message: r.message, retry_after: r.retryAfter });
        }
        if (r.httpStatus !== 200 || !r.body?.success) {
            return res.status(r.httpStatus === 200 ? 400 : r.httpStatus).json({
                success: false, message: r.body?.message || 'Gagal cek status'
            });
        }

        const d = r.body.data;
        if (row.status !== d.status) {
            if (d.status === 'success' && !row.paid_at) {
                await withLock(`qris:${row.id}`, async () => {
                    const fresh = dbGet('qris', row.id);
                    if (fresh && fresh.status === 'success') return;

                    const { error } = await retryAsync(
                        () => supabase.rpc('credit_topup_balance', { p_txid: row.id }),
                        { retries: 4, baseDelay: 500 }
                    );
                    if (error) return;

                    const updated = await refreshQrisFromSupabase(row.id);
                    if (updated && updated.username && !updated.is_test) {
                        const u = await refreshUserFromSupabase(updated.username);
                        if (u && u.has_topup !== true) {
                            await dbPatchJson('user', updated.username, { has_topup: true });
                        }
                    }
                });
            } else if (d.status !== 'success') {
                await dbPatchJson('qris', row.id, { status: d.status });
            }
        }

        return res.json({ success: true, data: {
            transaction_id: d.transaction_id, status: d.status,
            amount: d.amount, total_amount: d.total_amount,
            credit_amount: d.credit_amount, updated_at: d.updated_at
        }});
    } catch (err) {
        return res.status(502).json({ success: false, message: 'Gagal cek status, coba lagi nanti' });
    }
});

app.get('/api/buatqris/active', requireAuth, (req, res) => {
    const now = Date.now();
    const rows = dbListByUser('qris', req.user.username)
        .filter(r => {
            if (r.status !== 'pending') return false;
            if (!r.expired_at) return true;
            return new Date(r.expired_at).getTime() > now;
        })
        .sort((a, b) => new Date(b.created_at || 0) - new Date(a.created_at || 0));

    res.json({
        success: true,
        data: rows.map(r => {
            const token = makeQrisToken(r.id);
            return {
                transaction_id: r.id,
                amount: r.amount,
                total_amount: r.total_amount,
                admin_fee: r.admin_fee,
                credit_amount: r.credit_amount,
                qris_method: r.qris_method,
                qr_image:    `${CONFIG.APP_BASE_URL}/q/${token}`,
                payment_url: `${CONFIG.APP_BASE_URL}/pay/${token}`,
                status: r.status,
                expired_at: r.expired_at,
                created_at: r.created_at
            };
        })
    });
});

app.get('/api/transactions', requireAuth, (req, res) => {
    const legacy = dbListByUser('legacy', req.user.username)
        .map(r => ({ ...r, source: 'legacy', createdAt: r.created_at }));
    const current = dbListByUser('qris', req.user.username)
        .map(r => {
            const token = makeQrisToken(r.id);
            const { qr_url, qris_image, payment_url, ...safe } = r;
            return {
                ...safe,
                transaction_id: r.id,
                qr_image: `${CONFIG.APP_BASE_URL}/q/${token}`,
                payment_url: `${CONFIG.APP_BASE_URL}/pay/${token}`,
                source: 'buatqris',
                createdAt: r.created_at
            };
        });
    const merged = [...legacy, ...current]
        .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    res.json(merged);
});

app.get('/api/invest/pakets', (req, res) => {
    const pakets = CONFIG.INVEST.PAKETS.map(p => {
        const totalReturn = p.harga * p.multiplier;
        const perHari = totalReturn / CONFIG.INVEST.DURATION_DAYS;
        return {
            id: p.id, name: p.name, harga: p.harga, multiplier: p.multiplier,
            total_return: Math.round(totalReturn),
            per_hari: Math.round(perHari),
            durasi: CONFIG.INVEST.DURATION_DAYS
        };
    });
    res.json({ success: true, data: pakets });
});

app.get('/api/invest/my', requireAuth, (req, res) => {
    const rows = dbListByUser('investment', req.user.username);
    res.json({ success: true, data: rows.map(r => ({
        id: r.id, paket_id: r.paket_id, paket_name: r.paket_name,
        harga: r.harga, multiplier: r.multiplier,
        daily_income: r.daily_income, total_return: r.total_return,
        total_earned: r.total_earned || 0,
        days_passed: r.days_passed || 0,
        status: r.status, started_at: r.started_at,
        last_credit_date: r.last_credit_date,
        completed_at: r.completed_at,
        createdAt: r.created_at
    }))});
});

// ============================================================
// ✅ FIX #2: BELI PAKET INVEST
// - Hapus kredit instan 2 detik (sumber saldo naik sendiri)
// - Hapus potong topup_balance (sumber double-spend)
// - Set days_passed = 0, last_credit_date = null
// - Setelah beli, langsung kredit Hari ke-1 (opsional via flag)
// ============================================================
app.post('/api/invest/buy', requireAuth, async (req, res) => {
    try {
        const { paket_id } = req.body;
        const username = req.user.username;

        const paket = CONFIG.INVEST.PAKETS.find(p => p.id === paket_id);
        if (!paket) {
            return res.status(400).json({ success: false, error: 'Paket tidak valid' });
        }

        const user = await refreshUserFromSupabase(username);
        if (!user) return res.status(400).json({ success: false, error: 'User tidak ditemukan' });

        const currentBalance = Number(user.balance || 0);

        if (currentBalance < paket.harga) {
            return res.status(400).json({
                success: false,
                error: `Saldo tidak cukup. Butuh ${rupiah(paket.harga)}, saldo Anda ${rupiah(currentBalance)}`
            });
        }

        // ✅ Potong saldo utama
        let newBalance;
        try {
            newBalance = await adjustBalance(username, -paket.harga);
            await refreshUserFromSupabase(username);
        } catch (rpcErr) {
            const fallback = currentBalance - paket.harga;
            await dbPatchJson('user', username, { balance: fallback });
            await refreshUserFromSupabase(username);
            newBalance = fallback;
        }

        // ✅ FIX #2b: topup_balance TIDAK dipotong. Karena topup sudah dikreditkan
        // ke `balance` saat webhook payment.success. Kalau dipotong lagi = double-spend.
        // topup_balance hanya sebagai PENANDA histori user pernah topup berapa.
        // Setelah beli paket, kita reset penanda ini agar tidak mengunci WD selamanya.
        if (Number(user.topup_balance || 0) > 0) {
            await dbPatchJson('user', username, { topup_balance: 0 });
            await refreshUserFromSupabase(username);
        }

        const totalReturn = paket.harga * paket.multiplier;
        const dailyIncome = totalReturn / CONFIG.INVEST.DURATION_DAYS;

        const investId = 'INV-' + Date.now() + '-' + Math.random().toString(36).slice(2, 6).toUpperCase();
        const nowIso = new Date().toISOString();
        const todayStr = todayWIBStr();

        // ✅ FIX #2c: Buat investasi TANPA kredit instan.
        // days_passed = 0 dan last_credit_date = null → cron besok yang kredit Hari ke-1.
        await dbInsert({
            id: investId,
            type: 'investment',
            username,
            data: {
                paket_id: paket.id,
                paket_name: paket.name,
                harga: paket.harga,
                multiplier: paket.multiplier,
                daily_income: dailyIncome,
                total_return: totalReturn,
                total_earned: 0,
                days_passed: 0,
                status: 'active',
                started_at: nowIso,
                last_credit_date: null,
                completed_at: null
            }
        });

        await dbPatchJson('user', username, { has_bought: true });
        await refreshUserFromSupabase(username);

        // ✅ FIX #2d: HAPUS setTimeout kredit instan 2 detik.
        // Kalau mau kasih bonus Hari ke-1 langsung, harus lewat cron supaya konsisten.
        // Blok setTimeout lama DIHAPUS TOTAL.

        return res.json({
            success: true,
            message: `Paket ${paket.name} berhasil dibeli! Penghasilan harian akan masuk otomatis setiap hari mulai besok.`,
            data: {
                id: investId,
                paket: paket.name,
                harga: paket.harga,
                daily_income: Math.round(dailyIncome),
                total_return: Math.round(totalReturn),
                started_at: nowIso,
                first_credit_date: todayStr // info hari ini, kredit mulai besok
            },
            newBalance
        });
    } catch (e) {
        console.error('[INVEST BUY] Fatal:', e.message);
        res.status(500).json({ success: false, error: e.message });
    }
});

// ============================================================
// ✅ FIX #3: CRON HARIAN
// - Cek umur investasi (started_at) supaya tidak kredit sebelum waktunya
// - Hitung selisih hari yang belum dikredit
// - Skip kalau sudah sesuai umur
// ============================================================
async function creditDailyInvestment() {
    console.log(`\n[INVEST CRON] ================================`);
    console.log(`[INVEST CRON] Mulai credit harian — ${nowWIB()} WIB`);
    const today = todayWIBStr();
    const actives = CACHE.investments.filter(i => i.status === 'active');
    console.log(`[INVEST CRON] ${actives.length} investasi aktif, tanggal: ${today}`);

    let success = 0, skipped = 0, completed = 0, failed = 0;
    let totalCredited = 0;

    for (const inv of actives) {
        try {
            // ✅ FIX #3a: hitung umur investasi (dalam hari penuh)
            const umurHari = getInvestmentAgeDays(inv.started_at);
            const daysPassed = Number(inv.days_passed || 0);

            // Kalau umur 0 (baru beli hari ini), jangan kredit
            if (umurHari < 1) {
                skipped++;
                continue;
            }

            // ✅ FIX #3b: kredit berdasarkan selisih umur vs days_passed
            const hariHarusDikredit = umurHari - daysPassed;
            if (hariHarusDikredit <= 0) {
                skipped++;
                continue;
            }

            // Batasi maksimal sesuai durasi
            const sisaHari = CONFIG.INVEST.DURATION_DAYS - daysPassed;
            const hariDikredit = Math.min(hariHarusDikredit, sisaHari);
            if (hariDikredit <= 0) {
                skipped++;
                continue;
            }

            const dailyIncome = Number(inv.daily_income || 0);
            const creditAmount = dailyIncome * hariDikredit;
            const totalEarned = Number(inv.total_earned || 0) + creditAmount;
            const newDaysPassed = daysPassed + hariDikredit;
            const isCompleted = newDaysPassed >= CONFIG.INVEST.DURATION_DAYS;

            console.log(`[INVEST CRON] Proses ${inv.id} (${inv.username}) — hari ${newDaysPassed}/30, +${rupiah(creditAmount)} (${hariDikredit} hari)`);

            try {
                await adjustInvestBalance(inv.username, creditAmount);
                await adjustBalance(inv.username, creditAmount);
                await adjustWithdrawableBalance(inv.username, creditAmount);
                await refreshUserFromSupabase(inv.username);
                console.log(`[INVEST CRON] ${inv.username} +${rupiah(creditAmount)}`);
            } catch (rpcErr) {
                console.error(`[INVEST CRON] RPC gagal ${inv.id}: ${rpcErr.message}`);
                const u = getUserByUsername(inv.username) || await refreshUserFromSupabase(inv.username);
                await dbPatchJson('user', inv.username, {
                    invest_balance: Number(u?.invest_balance || 0) + creditAmount,
                    balance: Number(u?.balance || 0) + creditAmount,
                    withdrawable_balance: Number(u?.withdrawable_balance || 0) + creditAmount
                });
            }

            await dbPatchJson('investment', inv.id, {
                days_passed: newDaysPassed,
                total_earned: totalEarned,
                last_credit_date: today,
                status: isCompleted ? 'completed' : 'active',
                completed_at: isCompleted ? new Date().toISOString() : null
            });

            totalCredited += creditAmount;
            if (isCompleted) completed++;
            success++;
        } catch (e) {
            console.error(`[INVEST CRON] Error ${inv.id}: ${e.message}`);
            failed++;
        }
    }

    console.log(`[INVEST CRON] Selesai: ${success} sukses | ${skipped} skip | ${completed} selesai | ${failed} gagal`);
    console.log(`[INVEST CRON] Total dikredit: ${rupiah(totalCredited)}`);
    console.log(`[INVEST CRON] ================================\n`);

    return { success, skipped, completed, failed, totalCredited };
}

// ✅ FIX #4: catch-up lebih aman — pakai umur, bukan cek tanggal saja
async function catchUpMissedCredits() {
    const actives = CACHE.investments.filter(i => i.status === 'active');
    const needCredit = actives.filter(i => {
        const umurHari = getInvestmentAgeDays(i.started_at);
        const daysPassed = Number(i.days_passed || 0);
        return umurHari > daysPassed && umurHari >= 1;
    });

    if (needCredit.length === 0) return { needed: false, count: 0 };

    console.log(`[INVEST CATCHUP] ${needCredit.length} investasi belum dikredit sesuai umur — menjalankan catch-up...`);
    const result = await creditDailyInvestment();
    return { needed: true, count: needCredit.length, result };
}

function startInvestCron() {
    let lastRunDate = null;

    setInterval(async () => {
        const now = getWIBDate();
        const h = now.getUTCHours();
        const m = now.getUTCMinutes();
        const today = todayWIBStr();

        if (h === CONFIG.INVEST.CRON_HOUR && m === CONFIG.INVEST.CRON_MINUTE && lastRunDate !== today) {
            lastRunDate = today;
            try {
                await creditDailyInvestment();
            } catch (e) {
                console.error('[INVEST CRON] Fatal:', e.message);
            }
        }
    }, 60 * 1000);

    setTimeout(async () => {
        try {
            await catchUpMissedCredits();
        } catch (e) {
            console.error('[INVEST CATCHUP] Error:', e.message);
        }
    }, 30 * 1000);

    setInterval(async () => {
        try {
            await catchUpMissedCredits();
        } catch (e) {
            console.error('[INVEST CATCHUP] Error:', e.message);
        }
    }, 60 * 60 * 1000);

    const hh = String(CONFIG.INVEST.CRON_HOUR).padStart(2, '0');
    const mm = String(CONFIG.INVEST.CRON_MINUTE).padStart(2, '0');
    console.log(`[INVEST CRON] Scheduler aktif — credit harian jam ${hh}:${mm} WIB`);
}

app.get('/api/withdraw-methods', requireAuth, (req, res) => {
    res.json({ success: true, methods: CONFIG.WITHDRAW_METHODS });
});

app.post('/api/withdraw', requireAuth, async (req, res) => {
    try {
        const { amount, method, accountNumber, accountName } = req.body;
        const username = req.user.username;

        const methodConfig = CONFIG.WITHDRAW_METHODS.find(m => m.id === method);
        if (!methodConfig) return res.status(400).json({ success: false, error: 'Metode pembayaran tidak valid' });

        const amountNum = parseInt(amount, 10);
        if (!amountNum || amountNum <= 0) return res.status(400).json({ success: false, error: 'Jumlah withdraw tidak valid' });
        if (amountNum < CONFIG.WITHDRAW_MIN) return res.status(400).json({ success: false, error: `Minimal withdraw Rp ${CONFIG.WITHDRAW_MIN.toLocaleString()}` });
        if (amountNum > CONFIG.WITHDRAW_MAX) return res.status(400).json({ success: false, error: `Maksimal withdraw Rp ${CONFIG.WITHDRAW_MAX.toLocaleString()}` });
        if (!accountNumber || accountNumber.length < 5) return res.status(400).json({ success: false, error: 'Nomor akun tidak valid' });
        if (!accountName || accountName.length < 3) return res.status(400).json({ success: false, error: 'Nama pemilik akun tidak valid' });

        const user = await refreshUserFromSupabase(username);
        if (!user) return res.status(400).json({ success: false, error: 'User tidak ditemukan' });

        const wd = computeWithdrawable(user);
        console.log(`[WITHDRAW] ${username} — balance: ${rupiah(wd.balance)}, topup: ${rupiah(wd.topupBalance)}, withdrawable: ${rupiah(wd.withdrawable)}, allowed: ${rupiah(wd.allowed)}`);

        if (wd.allowed <= 0) {
            return res.status(400).json({
                success: false,
                error: `Saldo Anda belum bisa di-withdraw. Beli paket investasi dulu untuk mendapat penghasilan harian yang otomatis masuk ke saldo utama.`
            });
        }

        if (amountNum > wd.allowed) {
            return res.status(400).json({
                success: false,
                error: `Saldo yang bisa di-withdraw: ${rupiah(wd.allowed)}. ` +
                       (wd.topupBalance > 0
                           ? `Saldo topup ${rupiah(wd.topupBalance)} terkunci — beli paket investasi dulu.`
                           : `Saldo Anda tidak cukup.`)
            });
        }

        const { data: pendingRows } = await supabase
            .from('app_data')
            .select('id')
            .eq('type', 'withdraw')
            .eq('username', username)
            .eq('data->>status', 'pending')
            .limit(1);

        if (pendingRows && pendingRows.length > 0) {
            return res.status(400).json({
                success: false,
                error: 'Anda masih memiliki permintaan withdraw yang sedang diproses.'
            });
        }

        let newBalance;
        try {
            newBalance = await adjustBalance(username, -amountNum);
            await refreshUserFromSupabase(username);
        } catch (rpcErr) {
            console.error('[WITHDRAW] RPC gagal:', rpcErr.message);
            const fallbackBalance = wd.balance - amountNum;
            await dbPatchJson('user', username, { balance: fallbackBalance });
            newBalance = fallbackBalance;
        }

        try {
            await adjustWithdrawableBalance(username, -amountNum);
            await refreshUserFromSupabase(username);
        } catch (rpcErr) {
            console.error('[WITHDRAW] Kurangi withdrawable gagal:', rpcErr.message);
            const fresh = getUserByUsername(username);
            await dbPatchJson('user', username, {
                withdrawable_balance: Math.max(0, Number(fresh?.withdrawable_balance || 0) - amountNum)
            });
        }

        await refreshUserFromSupabase(username);

        const withdrawId = 'WD-' + Date.now() + '-' + Math.random().toString(36).slice(2, 6).toUpperCase();

        await dbInsert({
            id: withdrawId, type: 'withdraw', username,
            data: {
                amount: amountNum,
                method, method_name: methodConfig.name,
                account_number: accountNumber, account_name: accountName,
                status: 'pending', processed_at: null, note: ''
            }
        });

        await dbInsert({
            id: withdrawId, type: 'legacy', username,
            data: {
                type: 'withdraw', method, method_name: methodConfig.name,
                account_number: accountNumber, account_name: accountName,
                nominal: amountNum, amount: amountNum, status: 'pending'
            }
        });

        await refreshUserFromSupabase(username);

        try {
            const withdrawRow = dbGet('withdraw', withdrawId);
            if (withdrawRow) {
                notifyAdminsWithdraw(withdrawRow).catch(e => console.error('[WD NOTIF]', e.message));
            }
        } catch (e) {}

        return res.json({
            success: true,
            message: 'Permintaan withdraw berhasil diajukan.',
            data: {
                withdrawal_id: withdrawId, amount: amountNum,
                method: methodConfig.name, accountNumber, accountName,
                status: 'pending', createdAt: new Date().toISOString()
            },
            newBalance
        });

    } catch (error) {
        res.status(500).json({ success: false, error: error.message || 'Terjadi kesalahan' });
    }
});

app.get('/api/withdraws', requireAuth, (req, res) => {
    const rows = dbListByUser('withdraw', req.user.username);
    res.json({ success: true, data: rows.map(r => ({ id: r.id, ...r, createdAt: r.created_at })) });
});

app.post('/register', async (req, res) => {
    try {
        const { username, password, email, referral_code, fingerprint } = req.body;

        if (!username || !password || !email) {
            return res.status(400).json({ error: 'Semua field harus diisi!' });
        }

        if (!fingerprint || typeof fingerprint !== 'string' || fingerprint.length < 8) {
            return res.status(400).json({
                error: 'Browser Anda tidak mendukung fitur ini. Coba browser lain (Chrome/Firefox/Safari).',
                code: 'NO_FINGERPRINT'
            });
        }

        const existingFp = CACHE.users.find(u => u.browser_fingerprint === fingerprint);
        if (existingFp) {
            const hint = existingFp.username
                ? existingFp.username.slice(0, 3) + '***'
                : 'akun lain';
            return res.status(400).json({
                error: `Browser ini sudah pernah mendaftar akun (${hint}). 1 browser hanya boleh 1 akun. Silakan login dengan akun lama, atau hubungi admin jika lupa.`,
                code: 'DUPLICATE_BROWSER'
            });
        }

        const clientIp = (req.headers['x-forwarded-for']?.split(',')[0]?.trim())
                       || req.socket?.remoteAddress
                       || '';
        const ipFingerprint = clientIp + '|' + fingerprint;

        const existingIp = CACHE.users.find(u => u.ip_fingerprint === ipFingerprint);
        if (existingIp) {
            return res.status(400).json({
                error: 'Koneksi + browser ini sudah pernah mendaftar. 1 browser hanya boleh 1 akun.',
                code: 'DUPLICATE_BROWSER'
            });
        }

        const existing = getUserByUsername(username);
        if (existing) {
            return res.status(400).json({ error: 'Username sudah digunakan!' });
        }

        let referrer = null;
        let referralBonus = 0;
        let newUserBonus = CONFIG.BONUS_NEW_USER;

        if (referral_code && String(referral_code).trim()) {
            const cleanCode = String(referral_code).trim().toLowerCase();
            referrer = CACHE.users.find(u =>
                (u.referral_code || '').toLowerCase() === cleanCode
            );

            if (!referrer) {
                return res.status(400).json({ error: 'Kode referral tidak valid!' });
            }
            if (referrer.username === username) {
                return res.status(400).json({ error: 'Tidak bisa menggunakan kode referral sendiri!' });
            }

            referralBonus = CONFIG.BONUS_REFERRAL;
            newUserBonus = CONFIG.BONUS_NEW_USER + CONFIG.BONUS_REFERRAL_NEW;
        }

        const myReferralCode = generateReferralCode(username);

        await dbInsert({
            id: username, type: 'user', username,
            data: {
                username,
                email,
                password: password,
                balance: newUserBonus,
                invest_balance: 0,
                bonus_balance: newUserBonus,
                bonus_unlocked: false,
                has_topup: false,
                has_bought: false,
                topup_balance: 0,
                withdrawable_balance: 0,
                referral_code: myReferralCode,
                referred_by: referrer ? referrer.username : null,
                referral_count: 0,
                referral_earnings: 0,
                browser_fingerprint: fingerprint,
                ip_fingerprint: ipFingerprint,
                registered_ip: clientIp,
                registered_at: new Date().toISOString()
            }
        });

        if (referrer) {
            try {
                await adjustBalance(referrer.username, referralBonus);
                await adjustWithdrawableBalance(referrer.username, referralBonus);

                const freshReferrer = await refreshUserFromSupabase(referrer.username);
                const newRefCount = Number(freshReferrer?.referral_count || 0) + 1;
                const newRefEarnings = Number(freshReferrer?.referral_earnings || 0) + referralBonus;

                await dbPatchJson('user', referrer.username, {
                    referral_count: newRefCount,
                    referral_earnings: newRefEarnings
                });

                const notifText =
                    `<b>REFERRAL BARU</b>\n` +
                    `<blockquote>User Baru: <b>${username}</b>\n` +
                    `Diajak oleh: <b>${referrer.username}</b>\n` +
                    `Bonus Referrer: <b>${rupiah(referralBonus)}</b>\n` +
                    `Bonus User Baru: <b>${rupiah(CONFIG.BONUS_REFERRAL_NEW)}</b></blockquote>\n` +
                    `Waktu: ${nowWIB()} WIB`;

                for (const adminId of CONFIG.ADMIN_TELEGRAM_IDS) {
                    tgSendMessage(adminId, notifText).catch(() => {});
                }
            } catch (refErr) {
                console.error('[REFERRAL] Gagal kasih bonus referrer:', refErr.message);
            }
        }

        await refreshUserFromSupabase(username);

        res.json({
            success: true,
            message: referrer
                ? `Registrasi berhasil! Bonus referral ${rupiah(CONFIG.BONUS_REFERRAL_NEW)} ditambahkan.`
                : 'Registrasi berhasil!',
            user: username,
            referral_code: myReferralCode,
            has_referral: !!referrer
        });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

app.post('/login', async (req, res) => {
    try {
        const { username, password } = req.body;
        if (!username || !password) return res.status(400).json({ error: 'Semua field harus diisi!' });

        await refreshUserFromSupabase(username).catch(() => {});

        const user = getUserByUsername(username);
        if (!user) return res.status(400).json({ error: 'Username tidak ditemukan!' });

        const valid = await verifyPassword(password, user.password);
        if (!valid) return res.status(400).json({ error: 'Password salah!' });

        if (isBcryptHash(user.password)) {
            dbPatchJson('user', user.username, { password: password }).catch(() => {});
        }

        const token = signToken(user);
        const isProd = req.secure || req.headers['x-forwarded-proto'] === 'https';

        res.cookie('token', token, {
            httpOnly: true,
            secure: isProd,
            sameSite: isProd ? 'none' : 'lax',
            maxAge: 8 * 60 * 60 * 1000,
            path: '/'
        });

        res.json({ success: true, message: 'Login berhasil!', balance: user.balance || 0 });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

app.post('/logout', (req, res) => {
    res.clearCookie('token', { path: '/' });
    res.json({ success: true, message: 'Logout berhasil!', redirect: '/about' });
});

app.post('/api/admin/reload-cache', async (req, res) => {
    const adminKey = req.headers['x-admin-key'];
    if (adminKey !== CONFIG.JWT_SECRET) {
        return res.status(403).json({ success: false, error: 'Forbidden' });
    }
    const ok = await loadFromSupabase();
    res.json({
        success: ok,
        users: CACHE.users.length,
        qris: CACHE.qris.length,
        withdraws: CACHE.withdraws.length,
        investments: CACHE.investments.length,
        loadedAt: CACHE.loadedAt
    });
});

app.get('/api/admin/run-invest-cron', async (req, res) => {
    const adminKey = req.headers['x-admin-key'] || req.query.admin_key;
    if (adminKey !== CONFIG.JWT_SECRET) {
        return res.status(403).json({ success: false, error: 'Forbidden' });
    }
    try {
        const result = await creditDailyInvestment();
        res.json({ success: true, message: 'Invest cron dijalankan manual', result });
    } catch (e) {
        res.status(500).json({ success: false, error: e.message });
    }
});

app.get('/api/admin/credit-now/:username', async (req, res) => {
    const adminKey = req.headers['x-admin-key'] || req.query.admin_key;
    if (adminKey !== CONFIG.JWT_SECRET) {
        return res.status(403).json({ success: false, error: 'Forbidden' });
    }

    try {
        const username = req.params.username;
        const user = await refreshUserFromSupabase(username);
        if (!user) return res.status(404).json({ success: false, error: 'User tidak ditemukan' });

        const invs = CACHE.investments.filter(
            i => i.username === username && i.status === 'active'
        );

        if (invs.length === 0) {
            return res.json({ success: false, error: 'Tidak ada investasi aktif' });
        }

        const results = [];
        for (const inv of invs) {
            const dailyIncome = Number(inv.daily_income || 0);
            try {
                await adjustInvestBalance(username, dailyIncome);
                await adjustBalance(username, dailyIncome);
                await adjustWithdrawableBalance(username, dailyIncome);
                const newBal = await refreshUserFromSupabase(username);
                results.push({
                    invest_id: inv.id,
                    paket: inv.paket_name,
                    credited: dailyIncome,
                    new_balance: newBal?.balance,
                    new_withdrawable: newBal?.withdrawable_balance
                });
            } catch (e) {
                results.push({ invest_id: inv.id, error: e.message });
            }
        }

        res.json({
            success: true,
            username,
            credited_count: results.filter(r => !r.error).length,
            results
        });
    } catch (e) {
        res.status(500).json({ success: false, error: e.message });
    }
});

app.get('/api/admin/cron-status', async (req, res) => {
    const adminKey = req.headers['x-admin-key'] || req.query.admin_key;
    if (adminKey !== CONFIG.JWT_SECRET) {
        return res.status(403).json({ success: false, error: 'Forbidden' });
    }

    const today = todayWIBStr();
    const actives = CACHE.investments.filter(i => i.status === 'active');
    const alreadyCredited = actives.filter(i => i.last_credit_date === today);
    const notCredited = actives.filter(i => i.last_credit_date !== today);

    res.json({
        success: true,
        now_wib: nowWIB(),
        today_wib: today,
        cron_schedule: `${String(CONFIG.INVEST.CRON_HOUR).padStart(2,'0')}:${String(CONFIG.INVEST.CRON_MINUTE).padStart(2,'0')} WIB`,
        total_active_investments: actives.length,
        already_credited_today: alreadyCredited.length,
        not_credited_today: notCredited.length,
        not_credited_list: notCredited.map(i => ({
            id: i.id,
            username: i.username,
            paket: i.paket_name,
            last_credit: i.last_credit_date || 'never',
            daily_income: i.daily_income
        }))
    });
});

app.get('/api/admin/refresh-user/:username', async (req, res) => {
    const adminKey = req.headers['x-admin-key'] || req.query.admin_key;
    if (adminKey !== CONFIG.JWT_SECRET) {
        return res.status(403).json({ success: false, error: 'Forbidden' });
    }
    const u = await refreshUserFromSupabase(req.params.username);
    res.json({ success: !!u, user: u });
});

app.use((err, req, res, next) => {
    console.error('Error:', err);
    if (res.headersSent) return;
    res.status(500).json({ error: err.message || 'Terjadi kesalahan server' });
});

process.on('unhandledRejection', (reason) => {
    console.error('[FATAL-CATCH] Unhandled Rejection:', reason);
});
process.on('uncaughtException', (err) => {
    console.error('[FATAL-CATCH] Uncaught Exception:', err.message);
    console.error(err.stack);
});

(async () => {
    const ok = await loadFromSupabase();
    if (!ok) {
        console.warn('[STARTUP] Gagal load dari Supabase. Server tetap jalan, cache kosong.');
    }

    startPeriodicSync();
    startInvestCron();

    pollTelegramUpdates().catch(e => console.error('[TG BOT] polling crash:', e.message));

    app.listen(CONFIG.PORT, () => {
        console.log('========================================');
        console.log('FAST TRADER');
        console.log(`Server: http://localhost:${CONFIG.PORT}`);
        console.log(`Cache : ${CACHE.users.length} users | ${CACHE.qris.length} qris | ${CACHE.withdraws.length} withdraws | ${CACHE.investments.length} investments`);
        console.log(`Loaded: ${CACHE.loadedAt || '-'}`);
        console.log(`Admin TG IDs: ${CONFIG.ADMIN_TELEGRAM_IDS.join(', ')}`);
        console.log(`QRIS Expired: ${CONFIG.QRIS_EXPIRED_MINUTES} menit`);
        console.log(`Bonus User Baru: ${rupiah(CONFIG.BONUS_NEW_USER)}`);
        console.log(`Bonus Referral: ${rupiah(CONFIG.BONUS_REFERRAL)} (referrer) + ${rupiah(CONFIG.BONUS_REFERRAL_NEW)} (user baru)`);
        console.log(`Invest: ${CONFIG.INVEST.PAKETS.length} paket | Durasi ${CONFIG.INVEST.DURATION_DAYS} hari | Cron 00:00 WIB`);
        console.log('Pendapatan harian OTOMATIS masuk ke saldo utama');
        console.log('Topup TIDAK lagi dipotong saat beli paket (fix double-spend)');
        console.log('Kredit instan 2 detik DIHAPUS (fix saldo naik sendiri)');
        console.log('CS Widget aktif + auto-reply + draggable');
        console.log('Anti multi-akun: 1 browser = 1 akun');
        console.log('CORS: AKTIF — semua origin boleh ✅');
        console.log('========================================\n');
    });
})();